CREATE DATABASE myforum;

USE myforum;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(20) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table to store topics with links to the date of creation and user
CREATE TABLE topics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(50) UNIQUE,
    creation_id INT,    
    creation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (creation_id) REFERENCES users(id)
);

-- This table stores information about individual posts with rferences to the userid and cataegoryid
CREATE TABLE posts (
    post_id INT PRIMARY KEY AUTO_INCREMENT,
    c_id INT,
    heading VARCHAR(50) UNIQUE,
    content TEXT,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    creation_id INT,
    username VARCHAR(50),
    FOREIGN KEY (c_id) REFERENCES topics(id),
    FOREIGN KEY (creation_id) REFERENCES users(id),
    FOREIGN KEY (username) REFERENCES users(username)
);


CREATE TABLE topic_member (
    ship_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    topic_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (topic_id) REFERENCES topics(id),
    UNIQUE(user_id, topic_id)
);



-- Grant privileges
GRANT ALL PRIVILEGES ON myforum.* TO 'appuser'@'localhost';