module.exports = function (app, forumData) {
  //============================================ HOME PAGE   ====================================================
  app.get("/", (req, res) => {
    res.render("index", forumData);
  });

//============================================  ABOUT PAGE    ====================================================
  app.get("/about", (req, res) => {
    res.render("about", forumData);
  });
//============================================   Topics PAGES   ====================================================
app.get("/topics", (req, res) => {
  db.query("SELECT * FROM topics", (err, results) => {
    if (err) throw err;
    res.render("topics", { topics: results });
  });
});
  app.get('/gaming-posts', (req, res) => {
    const sqlQuery = `
      SELECT *
      FROM posts
      JOIN users ON posts.creation_id = users.id
      JOIN topics ON posts.c_id = topics.id
      WHERE topics.title = 'Gaming';
    `;
    db.query(sqlQuery, (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send('Error fetching gaming posts');
      } else {
        res.render('gaming-posts', { gamingPosts: result });
      }
    });
  });
  app.get('/food-posts', (req, res) => {
    const sqlQuery = `
      SELECT *
      FROM posts
      JOIN users ON posts.creation_id = users.id
      JOIN topics ON posts.c_id = topics.id
      WHERE topics.title = 'Food';
    `;
  
    db.query(sqlQuery, (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send('Error fetching food posts');
      } else {
        res.render('food-posts', { foodPosts: result });
      }
    });
  });

  app.get('/travel-posts', (req, res) => {
    const sqlQuery = `
      SELECT *
      FROM posts
      JOIN users ON posts.creation_id = users.id
      JOIN topics ON posts.c_id = topics.id
      WHERE topics.title = 'Travel';
    `;
  
    db.query(sqlQuery, (err, result) => {
      if (err) {
        console.error(err);
        res.status(500).send('Error fetching travel posts');
      } else {
        res.render('travel-posts', { travelPosts: result });
      }
    });
  });
  

//============================================   POSTS LIST    ====================================================
  app.get("/posts", (req, res) => {
    // GET THE POSTS from the database
    db.query("SELECT * FROM posts", (err, results) => {
      if (err) throw err;
      res.render("posts", { posts: results });
    });
  });

//============================================   ADD POSTS     ====================================================
app.get('/addpost', function (req, res) {
  res.render('addpost.ejs');
});

app.post('/postadded', function(req, res) {
  const { heading, content, topicId, userId, username } = req.body;

  const sqlQuery = 'INSERT INTO posts (heading, content, c_id, date, creation_id, username) VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, ?)';
  const postValues = [heading, content, topicId, userId, username];

  db.query(sqlQuery, postValues, (err, result) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Error adding the post.');
    } else {
      res.status(200).send('Post added successfully!');
    }
  });
});

app.get('/posts/:postId', (req, res) => {
  const postId = req.params.postId;

  db.query('SELECT * FROM posts WHERE post_id = ?', [postId], (err, postResult) => {
    if (err) {
      console.error(err);
      res.status(500).send('Error fetching post details');
    } else {
      if (postResult.length === 0) {
        res.status(404).send('Post not found');
      } else {
        const post = postResult[0];

        db.query(
          'SELECT * FROM posts WHERE creation_id = ? AND post_id != ?',
          [post.creation_id, postId],
          (err, relatedPostsResult) => {
            if (err) {
              console.error(err);
              res.status(500).send('Error fetching related posts');
            } else {
              res.render('individual-post', {
                post: post,
                relatedPosts: relatedPostsResult,
              });
            }
          }
        );
      }
    }
  });
});

//============================================  SEARCH POSTS    ====================================================
app.get("/search", function (req, res) {
  res.render("search.ejs", forumData);
});

app.get("/search-result", (req, res) => {
  const keyword = req.query.keyword;

  if (!keyword) {
    return res.redirect("/search");
  }
  const sqlQuery = `(SELECT 'Posts' AS type, post_id AS id, heading AS title, content AS description, date AS created_at FROM posts WHERE heading LIKE ?)
    UNION
    (SELECT 'topics' AS type, id, title, '' AS description, creation_date AS created_at FROM topics WHERE title LIKE ?) `;
  const params = [`%${keyword}%`, `%${keyword}%`];
  db.query(sqlQuery, params, (err, results) => {
    if (err) {
      console.error("Error searching:", err);
      return res.redirect("/search");
    }
    if (results.length === 0) {
      return res.send(`No results found for ${keyword}`);
    }

    const newData = Object.assign({}, forumData, {
      searchResults: results,
    });
    res.render("search-result.ejs", newData);
  });
});

//============================================   USER LIST         ====================================================
  app.get("/users", (req, res) => {
    db.query("SELECT * FROM users", (err, results) => {
      if (err) throw err;
      res.render("users", { users: results });
    });
  }); 
};