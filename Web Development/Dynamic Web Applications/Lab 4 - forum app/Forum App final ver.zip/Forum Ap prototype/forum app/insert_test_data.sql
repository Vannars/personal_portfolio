use myforum;
-- Inserting users
INSERT INTO users (username, password, email) VALUES
('gamerchef1', 'password1', 'gamerchef@test'),
('farareeds2', 'password2', 'farareeds@test'),
('notatroll3', 'password3', 'notatroll@test'),
('callistofire4', 'password4', 'callistofire4@test'),
('avidgamer5', 'password5', 'avidgamer@test'),
('foodie6', 'password6', 'foodie@test'),
('globetrotter7', 'password7', 'globetrotter@test');

-- Inserting topics/topics
INSERT INTO topics (title, creation_id) VALUES 
('Gaming', 1),
('Food', 2),
('Travel', 3);

-- Inserting posts
INSERT INTO posts (heading, content, c_id, creation_id, username) VALUES 
-- Gaming topic 1
('Gaming PC Investment?', 'I am tired of seeing so many fun games on PC. Should I invest in PC gaming?', 1, 1, 'gamerchef1'),
-- REPLY 1
( Null, 'Yes, theres so many good games on PC!', 1, 2, 'farareeds2'),

-- Gaming topic 2
('Best RPGs of All Time?', 'What are some of the best RPGs that everyone should play at least once?', 1, 5, 'avidgamer5'),
-- reply 2
(NULL, 'The Witcher 3 and Skyrim are absolute must-plays!', 1, 6, 'foodie6'),

-- Travel topic
('Solo Travel Tips?', 'Any tips for someone planning their first solo travel adventure?', 3, 7, 'globetrotter7'),
--  reply 1
(NULL, 'Be open to new experiences, stay cautious but embrace the adventure!', 3, 5, 'avidgamer5'),

-- Travel topic 2
('Rhodes, Greece Trip?', 'I want to travel to Greece and Rhodes seems nice. I heard about the wildfires and im not sure anymore. Should I still go?', 3, 2, 'farareeds2'),
-- REPLY 2
( NULL, 'Rhodes is biggest island in Greece and is a beautiful place to visit. The old town especially is a great place to enjoy some history and great food
if you are concerned about the implication of the wildfires dont let that disuade you. But be respectful. Tourism helps fund repairs!', 3, 3, 'notatroll3'),

-- Food topic 1
('Sushi Recommendations?', 'Looking for recommendations on the best sushi restaurants in Tokyo!', 2, 6, 'foodie6'),
-- reply 2
(NULL, 'I highly recommend trying Sushi Dai in Tsukiji Market for the freshest sushi!', 2, 7, 'globetrotter7'),

-- Food topic 2
('Mature cheese sucks! Change my mind.', 'I hate stinky cheese. I don’t know why people love it so much. Mild is much better, change my mind.', 2, 3, 'notatroll3'),
-- REPLY 2
(NULL, 'Nevermind changing it, you are out of your mind! :( ', 2, 4, 'callistofire4');



