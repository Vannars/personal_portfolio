const express = require('express') // This constant indicates that express modules will be used in the code 
const dt = require('./myfirstmodule.js') // this constant indicates that myfirstmodule (from lab2) will available to use in the code
const app = express() // app is a constant we will use to declare an express function
const port = 8000 // calls port 8000


app.get('/welcome/home', function(req, res) { // app calls express function .get to handle requets and responses using a function with arguments req ad res 
    res.write('<h1>Welcome to my home page!</h1>') // h1 tages used to headline the page
    res.write('<p>Pick a name by changing the end of url in the search bar as follows: /welcome/home/Haon </p>') // some instructions for changing the name
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/home">Home</a></p>'); // link to home
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/about">About</a></p>'); // link to about
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/date">Time and Date</a></p>'); //link to time and date
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/contact">Contact</a></p>'); // link to contact
    res.end(); // ends response
}); //closing brackets

app.get('/welcome/home/:user', function(req, res) { // app calls express function .get to handle requets and responses using a function with arguments req ad res 
    res.write('<h1>You chose the name: ' + req.params.user + '</h1>') //h1 tags which display some text and a request which takes/diplays the paramaters from the user input at the end of the url
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/home">Home</a></p>'); // link to home
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/about">About</a></p>'); // link to about
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/date">Time and Date</a></p>'); //link to time and date
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/contact">Contact</a></p>'); // link to contact
    res.end(); // ends response
}); // closing brackets

app.get('/welcome/about', function(req, res){ // app calls express function .get to handle requets and responses using a function with arguments req ad res 
     res.write('<h1>About me.</h1>') // h1 tag for the headline of the page
     res.write('<p> Hello! My name is Noah, and I am a second year Comp Sci Student. I have made this page as part of my second year module; Dynamic Web Applications.</p>') // short text explaining the page nothing special
     res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/home">Home</a></p>'); // link to home
     res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/about">About</a></p>'); // link to about
     res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/date">Time and Date</a></p>'); //link to time and date
     res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/contact">Contact</a></p>'); // link to contact
     res.end(); // ends response
}); //closing brackets


app.get('/welcome/contact', function(req, res){ // app calls express function .get to handle requets and responses using a function with arguments req ad res 
        res.write('<h1>Contact me.</h1>')
        res.write('<p>My email: ntamb002@gold.ac.uk</p>') 
        res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/home">Home</a></p>'); // link to home
        res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/about">About</a></p>'); // link to about
        res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/date">Time and Date</a></p>'); //link to time and date
        res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/contact">Contact</a></p>'); // link to contact
        res.end(); // ends response;
}); //closing brackets

app.get('/welcome/date', function(req, res){  // app calls express function .get to handle requets and responses using a function with arguments req ad res 
    res.write('<h1>This page displays the date and time.</h1>'+ dt.myDateTime()); 
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/home">Home</a></p>'); // link to home
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/about">About</a></p>'); // link to about
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/date">Time and Date</a></p>'); //link to time and date
    res.write('<p><a href="https://doc.gold.ac.uk/usr/737/welcome/contact">Contact</a></p>'); // link to contact
    res.end(); // ends response
}); // closing brackets
app.listen(port, () => console.log(`Example app listening on port ${port}!`)) // calls express function .listen and sends a console.log  to how that the server running (on port 8000)s
