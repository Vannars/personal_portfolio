module.exports = function (app, shopData) {

    // Handle our routes
    app.get('/', function (req, res) {
      res.render('index.ejs', shopData);
    });
    app.get('/about', function (req, res) {
      res.render('about.ejs', shopData);
    });
    app.get('/search', function (req, res) {
      res.render("search.ejs", shopData);
    });
  
    app.get('/search-result', function (req, res) {
      // searching in the database
      // making a constant that holds the user's input
      const keyword = req.query.keyword;
      // if statement redirecting the user to the search page if nothing is entered
      if (!keyword) {
        return res.redirect('/search');
      }
      // two variable declarations which are assigned to SQL statements that use comparisons on name for exact and similar results
      let sqlExactResult = "SELECT name, price FROM books WHERE name = ?";
      let sqlSimilarResult = "SELECT name, price FROM books WHERE name LIKE ?";
  
      // database query searches for the exactResult matching the user's input (keyword) and redirects if there's an error
      db.query(sqlExactResult, [keyword], (err, exactResult) => {
        console.log("commencing query")
        // this if statement returns an error if exact result query does not work and reirects to the search pahe 
        if (err) {
          console.log("err finding exact result"); // message to console about the rror 
          res.redirect('/search'); // redirect to home page if there's an error
        }
  
        // if exactResults aren't found in the database, this if statement starts the advanced search looking for similarResult
        if (exactResult.length === 0) {
          // If no exact match is found, search for similarResult
          db.query(sqlSimilarResult, [`%${keyword}%`], (err, similarResult) => { // wildcard tags ensure search is for partial similarities between keyword and database enries
            if (err) {
              console.log("found search2");
              res.redirect('/search'); // redirect to home page if there's an error
            }
            // if statement checks if the advanced search has failed and if so returns a message
            if (similarResult.length === 0) {
              console.log("found search in similar length");
              return res.send("You searched for " + keyword + " but found no results");
            }
  
            //similar results are sent to the client if they are found using
            // // newData variable contains an object storing shopData which populates an array of items found by the exactResult query for use in availableBooks
            let newData = Object.assign({}, shopData, {
              availableBooks: similarResult
            });
            console.log(newData);
            //render the result page
            res.render("search-result.ejs", newData);
          });
        } else {
          // if similarResult conditions aren't met (but are always checked) but exactResult is met then exactResult will be sent using res.render
          console.log("found search");
          // newData varible contains an object storing shopData which populates an array of items found by the exactResult query for use in availableBooks
          let newData = Object.assign({}, shopData, {
            availableBooks: exactResult
          });
          console.log(newData);
          //render the result page
          res.render("search-result.ejs", newData);
        }
      });
    });
  
    app.get('/register', function (req, res) {
      res.render('register.ejs', shopData);
    });
    app.post('/registered', function (req, res) {
      // saving data in database
      res.send(' Hello ' + req.body.first + ' ' + req.body.last + ' you are now registered!  We will send an email to you at ' + req.body.email);
    });
    // new route to display all books
    app.get('/list', function (req, res) {
      let sqlquery = "SELECT * FROM books"; // query database to get all the books
      // execute sql query
      db.query(sqlquery, (err, result) => {
        if (err) {
          res.redirect('./'); // redirect to home page if there's an error
        }
        let newData = Object.assign({}, shopData, {
          availableBooks: result
        });
        console.log(newData);
        res.render("list.ejs", newData);
      });
    });
  
    // ADD BOOK ROUTE HANDLER
    // when /addbook is visited the addbook.ejs file is rendered to format the page and shopData is loaded
    app.get('/addbook', function (req, res) {
      res.render("addbook.ejs", shopData);
    });
    // if the /addbook form is submitted the post /bookadded URL is returned with the function containing the database query which adds the entry to the database
    app.post('/bookadded', function (req, res) {
      // saving data in database
  
      let sqlquery = "INSERT INTO books (name, price) VALUES (?, ?)"; // an SQL query to insert entries by name and price depending on the user input in the /addbook form
      // execute SQL query
      let newrecord = [req.body.name, req.body.price]; // an array to store the name and price entered by the user to use in the database query 
      // this database query uses the newrecord array and SQL query statement to insert an entry into the database and returns an error if it fails
      db.query(sqlquery, newrecord, (err, result) => {
        if (err) {
          return console.error(err.message);
        } else {
          // the response message on this page to show which book has been added and some details about it
          res.send(' This book is added to database, Name: ' + req.body.name + ' Price ' + req.body.price);
        }
      });
    });
  
    // BARGAIN BOOKS HANDLER
    app.get('/bargainbooks', function (req, res) {
      let sqlquery = "SELECT name, price FROM books WHERE price < '20.00' "; // query database to get all the books
      // execute SQL query
      db.query(sqlquery, (err, result) => {
        if (err) {
          res.redirect('./'); // redirect to home page if there's an error
        }
        let newData = Object.assign({}, shopData, {
          availableBooks: result
        });
        console.log(newData);
        res.render("list.ejs", newData);
      });
    });
  
    // REMOVE BOOK HANDLER (NOT ASSESSED BUT MY PERSONAL EXTENSION (for practice))
    // when this URL is visited the remove book ejs file is rendered
    app.get('/removebook', function (req, res) {
      res.render("removebook.ejs", shopData);
    });
    // if the removebook form is submitted the post command is run
    app.post('/bookremoved', function (req, res) {
      // deleting data in database
      let sqlqueryNamePriceBookremoval = "DELETE FROM books WHERE name = ? AND price = ?"; // this is a line that deletes entries from the table by name and price
      let sqlqueryBookremoval = "DELETE FROM books WHERE name = ?"; // this line is an SQL query that deletes entries from the table by name ONLY
      // execute SQL query
      let recordremovebynameandprice = [req.body.name2, req.body.price]; // This array stores values from the HTML body for the name and price of the entry
      let recordremovebyname = [req.body.name]; // This array takes values from the HTML body for the name only
      // This database query will remove books by name and return an error if it fails
      db.query(sqlqueryBookremoval, recordremovebyname, (err, result) => {
  
        // This database query is nested inside the first query and will always run. It checks if pricing has been given and removes entries by price and name and returns an error if the query fails
        db.query(sqlqueryNamePriceBookremoval, recordremovebynameandprice, (err, result) => {
          if (err) {
            return console.error(err.message);
          }
        });
        if (err) {
          return console.error(err.message);
        } else {
          // Sends the final result of the database query which will display the name and price of the entry provided for removal
          res.send(req.body.name + '' + req.body.name2 + ' with PRICE: ' + req.body.price + '  has been removed from Berties Books Database. ( NOTE if PRICE was left empty, all ' + req.body.name + ' database entries have been removed)');
        }
      });
    });
  
  }