//import express and ejs and body-parser
var express = require('express')
var ejs = require('ejs')
var bodyParser = require('body-parser')

//create express application object
const app = express()
const port = 8000
app.use(bodyParser.urlencoded({
    extended: true
}))

app.use(express.static(__dirname + '/public'));


//set directory where Express will pick up the HTML files
// __dirname will get the current directory
app.set('views', __dirname + '/views');

//tell Express that we want to use EJS as the tmplating engine
app.set('view engine', 'ejs');

//Tell express how to process html files using EJS's rendering engine
app.engine('html', ejs.renderFile);

//Define our data
var shopData = {
    shopName: "BasedBrews",
    productCategories: ["Beer", "Wine", "Soft Drinks", "Hot Drinks"]
};
//Handle routes
app.get('/', function (req, res) {
    res.render('index.html', shopData);
});
app.get('/about', function (req, res) {
    res.render('about.html', shopData);
});
app.get('/search', function (req, res) {
    res.render('search.html', shopData);
});

app.get('/search-result', function (req, res) {
    //TODO: search in the database  
    res.send("You searched for: " + req.query.keyword);
})

app.get('/register', function (req, res) {
    res.render('register.html', shopData);
});

app.post('/registered', function (req, res) {
    // saving data in database
    res.send(' Hello ' + req.body.first + ' ' + req.body.last + ', you are now registered!');
});

//Start the web app listening

app.listen(port, () => console.log('Example app listening on port ' + port));
