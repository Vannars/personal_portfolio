public class Grade {
    // private instance variables subject and score
    private String subject;
    private double score;

    // constructor to set subject and score
    public Grade(String subject, double score) {
        this.subject = subject;
        this.score = score;
    }

    // Getters and setters for subject and score
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;

    }

    // static method which returns a letter grade of type of char for a parameter
    // score of type double
    public static char getLetterGrade(double score) {
        if (score >= 70.0) {
            return 'A';
        } else if (score >= 60) {
            return 'B';
        } else if (score >= 50) {
            return 'C';
        } else if (score >= 40) {
            return 'D';
        } else if (score < 0 || score > 100) {
            return 'E';
        } else {
            return 'F';
        }

    }

}
