import java.util.ArrayList;
import java.util.Scanner;

public class StudentMain {
    private static ArrayList<Student> studentsArray = new ArrayList<>();

    public static void main(String[] args) {

        // DEFAULT STUDENT INFORMATION
        Student firstStudent = new Student("Bert Smith", "computing", 21, 12345, true);
        firstStudent.grades.add(new Grade("programming", 52));
        firstStudent.grades.add(new Grade("web dev", 63));
        firstStudent.grades.add(new Grade("maths", 76));
        firstStudent.grades.add(new Grade("algorithms", 68));
        studentsArray.add(firstStudent);

        Student secondStudent = new Student("Olivia Green", "computing", 19, 23464, true);
        secondStudent.grades.add(new Grade("programming", 73));
        secondStudent.grades.add(new Grade("web dev", 82));
        secondStudent.grades.add(new Grade("maths", 72));
        secondStudent.grades.add(new Grade("algorithms", 66));
        studentsArray.add(secondStudent);

        Student thirdStudent = new Student("Eloise Jones", "computing", 18, 34744, true);
        thirdStudent.grades.add(new Grade("programming", 65));
        thirdStudent.grades.add(new Grade("web dev", 63));
        thirdStudent.grades.add(new Grade("maths", 37));
        thirdStudent.grades.add(new Grade("algorithms", 49));
        studentsArray.add(thirdStudent);

        Student fourthStudent = new Student("Ben Bird", "computing", 42, 34834, false);
        fourthStudent.grades.add(new Grade("programming", 55));
        fourthStudent.grades.add(new Grade("web dev", 29));
        fourthStudent.grades.add(new Grade("maths", 56));
        fourthStudent.grades.add(new Grade("algorithms", 38));
        studentsArray.add(fourthStudent);

        Student fifthStudent = new Student("Karen Brown", "computing", 25, 45632, false);
        fifthStudent.grades.add(new Grade("programming", 62));
        fifthStudent.grades.add(new Grade("web dev", 51));
        fifthStudent.grades.add(new Grade("maths", 43));
        fifthStudent.grades.add(new Grade("algorithms", 43));
        studentsArray.add(fifthStudent);

        mainMenu();
    }

    // MENU SYSTEM IMPLEMENTATION
    // 1) Adding new students

    private static void addStudent() {
        // scanner to read student input of the name
        Scanner scanner = new Scanner(System.in);
        // enter a name scanner reads .nextline() (the user input) and sets this for
        // name.
        System.out.println("Enter name:");
        String name = scanner.nextLine();

        // same process as above
        System.out.println("Enter department:");
        String department = scanner.nextLine();
        // same process as above
        System.out.println("Enter age:");
        int age = scanner.nextInt();
        scanner.nextLine(); // newline character gets removed for next int

        System.out.println("Enter student number:");
        int studentNumber = scanner.nextInt();
        scanner.nextLine(); // same as above for next int
        // calling type student and creating a new student with the parameters we have
        // set up

        System.out.println("Enter fulltime true or false");
        boolean fullTime = scanner.nextBoolean();

        // newStudent of type student with all the paramters
        Student newStudent = new Student(name, department, age, studentNumber, fullTime);
        // this loop allows a grade to be added to each module each time the loop is ran
        // by taking user input from the scanner
        for (int i = 0; i < 4; i++) {
            System.out.println("Enter grade for Module " + (i + 1) + ":");
            double grade = scanner.nextDouble();
            scanner.nextLine(); // Consume newline character
            // adds the student grade to the grades array
            newStudent.grades.add(new Grade("Module " + (i + 1), grade));
        }

        studentsArray.add(newStudent);
        System.out.println("New student added successfully!");
    }

    // 2)Populate reports over the students array using student of type student
    private static void printStudentReports() {
        for (Student student : studentsArray) {
            System.out.println("Student Name: " + student.getName());
            System.out.println("Department: " + student.getDepartment());
            System.out.println("Student Number: " + student.getStudentNumber());
            System.out.println("Full Time: " + student.getfullTime());
            System.out.println("Grades: ");
            for (Grade grade : student.grades) {
                System.out.println(grade.getSubject() + ": " + grade.getScore() + " Grade: "
                        + Grade.getLetterGrade(grade.getScore()));
            }
            System.out.println(); // For separating different students
        }
    }

    // 3) print the average grade of a student
    private static void printGradeAvg() {
        // Iterate over the student arraylist to check for student of type Student
        // Default score total will be 0.
        for (Student student : studentsArray) {
            double totalScore = 0;
            // obtain the grade of type Grade for each student from the grade list
            // Add to totalscore by looping through the students grades and incrementing
            // total score by that amount
            for (Grade grade : student.grades) {
                totalScore += grade.getScore();
            }
            // exit the innter loop and use the totalscore value (from the inner loop)
            // divided by the number of subjects (using .size() in the student.grades array)
            // print out a line declaring the current student and their average grade
            double averageGrade = totalScore / student.grades.size();
            System.out.println(student.getName() + "has an avrage grade of: " + averageGrade);
            // at this point the loop will restart with a new student, resetting total value
            // to 0.
            // else if the array has been fully parsed over then the loop will exit as all
            // average grades wil have been found
        }
    }

    // 4) Print student name with failed module
    private static void printModuleFails() {
        // Iterate ovver the students array looking at the students
        for (Student student : studentsArray) {
            boolean failed = false;
            // check for each student their grade over the student grades array
            for (Grade grade : student.grades) {
                // if the grade returned is a F then failed becomes true
                if (Grade.getLetterGrade(grade.getScore()) == 'F') {
                    failed = true;
                    break;
                }
            }

            // if failed be comes true the student name gets printed along with
            if (failed) {
                System.out.println(student.getName() + " has failed modules");
            }

        }
    }

    private static void mainMenu() {
        // new scanner for the menu

        Scanner menuScanner = new Scanner(System.in);
        // assume exit hasnt occured
        boolean exitMenu = false;

        while (!exitMenu) {
            // Display the menu
            System.out.println("Main Menu:");
            System.out.println("1. Add a new student");
            System.out.println("2. Print reports of all students with letter grades");
            System.out.println("3. Print the grade average for each student");
            System.out.println("4. Print the names of students who have failed modules");
            System.out.println();

            // user input implementation
            System.out.println("Enter an interger (1-4, or 0 to exit) to select a menu option:");
            System.out.println();
            // checks user input
            int choice = menuScanner.nextInt();
            menuScanner.nextLine(); // \n is removed

            // switch statements for each case (functions/menu options)
            switch (choice) {

                // user cases for the menus
                case 1:
                    addStudent();
                    System.out.println();
                    break;

                case 2:
                    printStudentReports();
                    System.out.println();
                    break;

                case 3:
                    printGradeAvg();
                    System.out.println();
                    break;

                case 4:
                    printModuleFails();
                    System.out.println();
                    break;

                // exit the menu case
                case 0:
                    exitMenu = true;
                    break;

                // default message
                default:
                    System.out.println("Please enter a number from 1-4 for menu options of 0 to exit");
                    System.out.println();
            }
        }
        menuScanner.close();
    }

}
