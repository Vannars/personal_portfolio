import java.util.ArrayList;

public class Student {
    private String name;
    private String department;
    private int age;
    private String userName;
    private int studentNumber;
    private boolean fullTime;

    // NAME GETTERS AND SETTERS
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // DEPARTMENT GETTERS AND SETTERS
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    // AGE GETTERS AND SETTERS
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // USERNAME GETTERS AND SETTERS
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    // STUDENT NUMBER GETTERS AND SETTERS
    public int getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }

    // FULLTIME GETTERS AND SETTERS
    public boolean getfullTime() {
        return fullTime;
    }

    public void setFullTime(boolean fullTime) {
        this.fullTime = fullTime;
    }

    // here is what I use to generate a user name
    public void genUserName() {
        // this string array nameComponenets splits the name into two parts (First name
        // and surname) based on the " " space
        String[] nameComponents = name.split(" ");
        // First if statment find the first initial from the first name at array 0
        // (component 1) and n lowercase
        if (nameComponents.length >= 2) {
            String initial = nameComponents[0].substring(0, 1).toLowerCase();
            String surname = nameComponents[1].toLowerCase();

            // Second embedded if statment checks the length of the surname and takes the
            // first 4 characters
            // then adds 3 digit from the student number
            if (surname.length() >= 4) {
                String surnameComp = surname.substring(0, 4);
                String studentNumString = String.valueOf(studentNumber);
                String studentNumComp = studentNumString.length() >= 3 ? studentNumString.substring(0, 3)
                        : studentNumString;

                // if the conditions are met
                userName = initial + surnameComp + studentNumComp;
            } else {
                userName = initial + surname + String.valueOf(studentNumber).substring(0, 3);
            }
            userName = userName.toLowerCase();
        } else {
            userName = "NULL";
        }

    }

    public Student(String name, String department, int age, int studentNumber, boolean fullTime) {
        this.name = name;
        this.department = department;
        this.age = age;
        this.studentNumber = studentNumber;
        this.fullTime = fullTime;
        genUserName();
    }

    // array list whih stores type grade;
    public ArrayList<Grade> grades = new ArrayList<>();

}
