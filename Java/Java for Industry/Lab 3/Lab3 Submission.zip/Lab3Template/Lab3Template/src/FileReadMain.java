import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileReadMain {
    public static void main(String[] args) {
        // My relative path to the text file
        String filePath = "Lab3Template/Metamorphosis.txt";
        // initialise default values for the character, word, sentence, paragraph count
        // initialise boolean to show position as being in or outside of a paragraph
        int characterCount = 0;
        int wordCount = 0;
        int sentencesCount = 0;
        int paragraphCount = 0;
        boolean inParagraph = false;
        // Arrays to store text words and their frequencies
        String[] wordsArray = new String[21940]; // Array stores words accoding to the exact word count
        int wordArrayIndex = 0;
        int[] frequencyArray = new int[21940]; // Array stores frequencies assuming every word appears once

        try {
            // Scanner reads the txt file from the filePath
            Scanner scanner = new Scanner(new File(filePath), "UTF-8"); // Specify UTF-8 encoding

            // Until the end of the document the scanner will run
            while (scanner.hasNextLine()) {

                // check line remove spaces at the end with trim()
                String line = scanner.nextLine().trim();

                // Increment count using the length of each line
                characterCount += line.length();

                // Check next word by splitting where a " " is used
                String[] words = line.split("\\s+");

                // Increment word count by length of words array
                wordCount += words.length;

                // Check for sentences (punctuation) if the line contains characters
                if (!line.isEmpty()) {
                    // Increment sentence count for each sentence-ending punctuation mark within a
                    // line
                    sentencesCount += line.split("[.!?]\\s*").length; // \\s* checks for whitespace/linebreaks etc to
                                                                      // increment sentences
                }

                // Check for paragraphs first by empty lines
                if (line.isEmpty()) {
                    if (inParagraph) {
                        // If an empty line follows a populated line - this is counted as a paragraph
                        paragraphCount++;
                        inParagraph = false;
                    }
                } else {
                    inParagraph = true;
                }

                // Counts final paragraph if the file does not end with an empty line
                if (inParagraph) {
                    paragraphCount++;
                }

                // FREQUENCY COUNT
                // iterate over the String[] words array (defined earlier )
                for (String word : words) {
                    // Remove special characters at the end of words
                    word = word.replaceAll("[^a-zA-Z0-9'], '...' ", "").toLowerCase();

                    // if a word is present
                    if (!word.isEmpty()) {
                        // check if word ends with 's if so subtract from the substring value to treat
                        // them as the same word minus the 's
                        if (word.endsWith("'s")) {
                            word = word.substring(0, word.length() - 2);
                            // if punctuation is used subtract from the substring value to idenifty the
                            // single word without punctuation
                        } else if (word.endsWith(",") || word.endsWith("!") || word.endsWith(".")
                                || word.endsWith("?")) {
                            word = word.substring(0, word.length() - 1);
                        }

                        // If our word already exists in the array of words (false by default)
                        boolean wordAlreadyExists = false;
                        // iterate over the index for list of words looking for the current word i. exit
                        // loop if found
                        // first loop ran will always run the entire index
                        for (int i = 0; i < wordArrayIndex; i++) {
                            if (wordsArray[i].equals(word)) {
                                frequencyArray[i]++;
                                wordAlreadyExists = true;
                                break;
                            }
                        }

                        // If the word is new , we add it to the array
                        if (!wordAlreadyExists) {
                            wordsArray[wordArrayIndex] = word;
                            // this frequency array = 1 value will only occur on the first occurance of the
                            // word
                            frequencyArray[wordArrayIndex] = 1;
                            // increment the array index
                            wordArrayIndex++;
                        }
                    }
                }
            }

            // Close scanner at the end of txt file
            scanner.close();

            // Output for characters, words, sentencess, and paragraphs
            System.out.println("Characters: " + characterCount);
            System.out.println("Words: " + wordCount);
            System.out.println("Sentences: " + sentencesCount);
            System.out.println("Paragraphs: " + paragraphCount);

            // Using PrintWriter utility  we can write out word frequency list to the frequencies.txt
            PrintWriter writer = new PrintWriter("frequencies.txt");
            for (int i = 0; i < wordArrayIndex; i++) {
                //populate text file with words from the words array and the corresponding frequency from the frequency array
                writer.println(wordsArray[i] + ": " + frequencyArray[i]);
            }
            //similar to scanner, close writing (stop writing to the new text file)
            writer.close();

            // Message in console - frequences added to frequencies.txt
            System.out.println("Freuqencies length is: " + frequencyArray.length);
            System.out.println("Word frequencies have been added to frequencies.txt");

        } catch (FileNotFoundException e) {
            // If we cannot find the file (txt file) print out the this message
            System.out.println("Err file not found: " + e.getMessage());
        }
    }
}
