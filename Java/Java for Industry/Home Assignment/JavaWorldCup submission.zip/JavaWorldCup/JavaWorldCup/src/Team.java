public class Team extends Squad{

    Team(String teamName, Manager manager) {
        super(teamName, manager);
    }
}
