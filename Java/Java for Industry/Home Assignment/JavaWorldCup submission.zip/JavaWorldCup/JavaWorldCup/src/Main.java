import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {
    public static Squad[] squads = new Squad[32];

    public static void main(String[] args) {

        // 7.1) Create the file path to the the manager and players files
        String managersFilePath = "JavaWorldCup/JavaWorldCup/Managers.csv";
        String playersFilePath = "JavaWorldCup/JavaWorldCup/Players.csv";

        // 7.2) Array lists to store the managers and players properties
        ArrayList<Manager> managers = new ArrayList<>();
        ArrayList<Player> players = new ArrayList<>();

        // 7.3A) Create a Scanner for Managers.csv - Plan:
        // - skip the heading (using a conditional)
        // - split the data into a string array[] (split at commas)
        // - create manager objects using accurate string array[] indexes for each for
        // argument in the manager constructor
        try {

            Scanner managersScanner = new Scanner(new File(managersFilePath), "UTF-8"); // This is a little buggy >
            // file path isnt always found -
            // I set the character set to
            // UTF 8 as a work around - the complete character set for special characters
            // isnt fully recognised

            // The following conditional runs first and only once - skipping the heading
            // (atline 1)
            if (managersScanner.hasNextLine()) {
                managersScanner.nextLine();
            }

            // The following conditional runs and splits properties at every "," until the
            // end of the file
            while (managersScanner.hasNextLine()) {
                String next = managersScanner.nextLine();
                String[] mProperties = next.split(",");

                // Create a manager
                Manager Manager = new Manager(
                        mProperties[0].trim(),
                        mProperties[1].trim(),
                        mProperties[2].trim(),
                        mProperties[3].trim(),
                        // convert string double data from string (in csv file) to double
                        Double.parseDouble(mProperties[4].trim()),
                        Double.parseDouble(mProperties[5].trim()),
                        Double.parseDouble(mProperties[6].trim()),
                        Double.parseDouble(mProperties[7].trim()));

                // Add manager object made from the constructor to managers arraylist and to
                // squads

                // NOTE TO SELF: Manual addition of managers to squads - check for bounds

                // Add squad object to squads array based on CURRENT size of managers array
                // (array is empty to start so first squad is at squads[0])
                squads[managers.size()] = new Squad(mProperties[2].trim(), Manager);

                // Add Manager to managers (increases managers.size to 1 keeping in line with
                // indexing)
                managers.add(Manager);
            }
            managersScanner.close();
        }
        // Error if Managers.csv is not found
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }

        // 7.2B) Create a Scanner for Players.csv
        try {
            Scanner playersScanner = new Scanner(new File(playersFilePath), "UTF-8");

            // The following conditional runs first and only once - skipping the heading
            // (atline 1)
            if (playersScanner.hasNextLine()) {
                playersScanner.nextLine();
            }

            while (playersScanner.hasNextLine()) {
                String next = playersScanner.nextLine();
                String[] pProperties = next.split(",");

                // Create a Player
                Player Player = new Player(
                        pProperties[0].trim(),
                        pProperties[1].trim(),
                        pProperties[2].trim(),
                        pProperties[3].trim(),
                        Double.parseDouble(pProperties[4].trim()),
                        Double.parseDouble(pProperties[5].trim()),
                        Double.parseDouble(pProperties[6].trim()),
                        Double.parseDouble(pProperties[7].trim()),
                        Double.parseDouble(pProperties[8].trim()),
                        Double.parseDouble(pProperties[9].trim()),
                        Double.parseDouble(pProperties[10].trim()),
                        Double.parseDouble(pProperties[11].trim()),
                        Double.parseDouble(pProperties[12].trim()),
                        Double.parseDouble(pProperties[13].trim()));
                // Add player
                for (Squad squad : squads) {
                    if (squad != null && squad.getTeamName().equals(Player.getTeam())) {
                        squad.addPlayer(Player);
                        break;
                    }
                }
                players.add(Player);
            }

            playersScanner.close();
        }
        // Error if Players.csv is not found
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }

        // vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvTESTING
        // CODEvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
        // Test code to print squads and their players
        for (Squad squad : squads) {
            if (squad != null) {
                System.out.println(); // Empty line for separation
                System.out.println("Team: " + squad.getTeamName());
                System.out.println(
                        "Manager: " + squad.getManager().getFirstName() + " " +
                                squad.getManager().getSurname());
                System.out.println("Players:");
                int playersCount = 0;

                while (true) {
                    Player player = squad.getPlayer(playersCount);
                    if (player != null && playersCount <= 24) {
                        System.out.print(player.getFirstName() + " " + player.getSurname() + ", ");
                        playersCount++;
                    } else {
                        System.out.print(player.getFirstName() + " " + player.getSurname() + " ");
                        System.out.println();
                        break;
                    }
                }
            }

        }
        // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^TESTING
        // CODE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        // Test the getTeam method for each squad
        for (Squad squad : squads) {
            if (squad != null) {
                // Get the team from the squad
                Team team = getTeam(squad);

                // Print the team players
                printTeamPlayers(team);
            }
        }

        Main.runTournament();

    }

    public static double playerRatingAtIndex(Squad s, int n) {
        double sum = s.getPlayer(n).getAggression() +
                s.getPlayer(n).getChanceCreation() +
                s.getPlayer(n).getDefensiveness() +
                s.getPlayer(n).getDribbling() +
                s.getPlayer(n).getFitness() +
                s.getPlayer(n).getOffsideAdherence() +
                s.getPlayer(n).getPassingAccuracy() +
                s.getPlayer(n).getShotAccuracy() +
                s.getPlayer(n).getShotFrequency();
        return sum;
    }

    // Implement comparator of two players (p1, p2) of type Player
    public static class ComparePlayers implements Comparator<Player> {
        @Override
        public int compare(Player p1, Player p2) {

            // take average attributes for both players
            double avgAttributes1 = avgAttributes(p1);
            double avgAttributes2 = avgAttributes(p2);
            // return better player
            return Double.compare(avgAttributes2, avgAttributes1);
        }

        // Calculate the average attributes of a player (take 9 attributes of Player
        // player and divide them by 9)
        private double avgAttributes(Player player) {
            return (player.getAggression() +
                    player.getChanceCreation() +
                    player.getDefensiveness() +
                    player.getDribbling() +
                    player.getFitness() +
                    player.getOffsideAdherence() +
                    player.getPassingAccuracy() +
                    player.getShotAccuracy() +
                    player.getShotFrequency()) / 9.0;
        }
    }

    public static Team getTeam(Squad s) {

        // select formation and initial team
        String managerFormation = s.getManager().getFavouredFormation();
        Team t = new Team(s.getTeamName(), s.getManager());

        // assign relevant numeric representation of manager formation string using
        // index
        // values (0-2-4) to their respective positions
        int defenders = Character.getNumericValue(managerFormation.charAt(0));
        int midfielders = Character.getNumericValue(managerFormation.charAt(2));
        int forwards = Character.getNumericValue(managerFormation.charAt(4));

        // create some lists to hold players to be sorted and teamPlayers once sorted
        ArrayList<Player> sortPlayers = s.getPlayers();
        ArrayList<Player> teamPlayers = new ArrayList<>();

        // sortPlayers in this list by comparing players
        sortPlayers.sort(new ComparePlayers());

        // Just some initialised counters for player types
        int defenderCount = 0;
        int midfielderCount = 0;
        int forwardCount = 0;
        int goalKeeperCount = 0;

        for (Player player : sortPlayers) {

            // Adding defenders by number in formation (defenders)
            if (player.getPosition().equals("Defender") && defenderCount < defenders) {
                teamPlayers.add(player);
                defenderCount++;
            }

            // Adding midfielders by number in formation (midfielders)
            if (player.getPosition().equals("Midfielder") && midfielderCount < midfielders) {
                teamPlayers.add(player);
                midfielderCount++;
            }

            // Adding forward players by number in formation (forwards)
            if (player.getPosition().equals("Forward") && forwardCount < forwards) {
                teamPlayers.add(player);
                forwardCount++;
            }

            // Adding goal keeper (1 goal keeper)
            if (player.getPosition().equals("Goal Keeper") && goalKeeperCount < 1) {
                teamPlayers.add(player);
                goalKeeperCount++;
            }
        }

        t.getPlayers().addAll(new ArrayList<>(teamPlayers));

        return t;
    }

    // vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvTESTING
    // CODEvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
    private static void printTeamPlayers(Team team) {
        System.out.println();
        System.out.println("Team Players for " + team.getTeamName() + ":");
        System.out.println();
        System.out.println("Defenders: ");
        for (Player player : team.getPlayers()) {
            if (player.getPosition().equals("Defender")) {
                System.out.print(player.getFirstName() + " " + player.getSurname() + "   ");
            }
        }

        System.out.println();
        System.out.println();

        System.out.println("Midfielders: ");
        for (Player player : team.getPlayers()) {
            if (player.getPosition().equals("Midfielder")) {
                System.out.print(player.getFirstName() + " " + player.getSurname() + "   ");
            }
        }

        System.out.println();
        System.out.println();

        System.out.println("Forwards: ");
        for (Player player : team.getPlayers()) {
            if (player.getPosition().equals("Forward")) {
                System.out.print(player.getFirstName() + " " + player.getSurname() + "   ");
            }
        }

        System.out.println();
        System.out.println();

        System.out.println("Goal keeper: ");
        for (Player player : team.getPlayers()) {
            if (player.getPosition().equals("Goal Keeper")) {
                System.out.print(player.getFirstName() + " " + player.getSurname() + "   ");
            }
        }

        System.out.println();
        System.out.println();
    }
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^TESTING
    // CODE^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    public static void matchSimulation(List<Team> group) {
        System.out.println("Group Stage match results: ");

        // Map takes a string value and integer key integer and will be used to store
        // points
        Map<String, Integer> teamPointsMap = new HashMap<>();
        // looking at team objects in the group every team will be given a points value
        // starting at 0
        for (Team team : group) {
            teamPointsMap.put(team.getTeamName(), 0); // Initialize points to 0 for each team
        }
        // These two nested for loops are responsible for looking at each team across
        // the group list
        for (int i = 0; i < group.size(); i++) {
            System.out.println();
            for (int j = i + 1; j < group.size(); j++) {

                // Random result - goals scored arent based on team/player attributes :(
                Random decider = new Random();

                // Assign teams to indexes (this should ensure each team in a group faces each
                // member once)
                Team teamA = group.get(i);
                Team teamB = group.get(j);

                // Calculate scores
                int teamAScore = decider.nextInt(4);
                int teamBScore = decider.nextInt(4);

                System.out.println("Today's match-up is " + teamA.getTeamName() + " vs " + teamB.getTeamName());
                System.out.println("After 90 minutes and two halves the score is: " + teamAScore + " - " + teamBScore);

                if (teamAScore > teamBScore) {
                    System.out.println("Match Winner: " + teamA.getTeamName());
                    teamPointsMap.put(teamA.getTeamName(), teamPointsMap.get(teamA.getTeamName()) + 3); // Team A wins -
                                                                                                        // 3 points
                } else if (teamAScore < teamBScore) {
                    System.out.println("Match Winner: " + teamB.getTeamName());
                    teamPointsMap.put(teamB.getTeamName(), teamPointsMap.get(teamB.getTeamName()) + 3); // Team B wins -
                                                                                                        // 3 points
                } else {
                    // Check for a draw state
                    if (teamAScore == teamBScore) {
                        System.out.println("We have a draw - going to extra time!");

                        // (less chance to score in extra time due to player fatigue)
                        int extraTimeTeamAScore = decider.nextInt(2);
                        int extraTimeTeamBScore = decider.nextInt(2);

                        // Match score after extra time
                        teamAScore = teamAScore + extraTimeTeamAScore;
                        teamBScore = teamBScore + extraTimeTeamBScore;
                        System.out.println(
                                "After 90 minutes and extra time the score is: " + teamAScore + " - " + teamBScore);

                        if (teamAScore > teamBScore) {
                            System.out.println("Match Winner: " + teamA.getTeamName());
                            teamPointsMap.put(teamA.getTeamName(), teamPointsMap.get(teamA.getTeamName()) + 3); // Team
                                                                                                                // A
                                                                                                                // wins
                                                                                                                // - 3
                                                                                                                // points
                        } else if (teamAScore < teamBScore) {
                            System.out.println("Match Winner: " + teamB.getTeamName());
                            teamPointsMap.put(teamB.getTeamName(), teamPointsMap.get(teamB.getTeamName()) + 3); // Team
                                                                                                                // B
                                                                                                                // wins
                                                                                                                // - 3
                                                                                                                // points
                        } else {
                            // If a draw state still occurs
                            if (teamAScore == teamBScore) {
                                System.out.println("We have a draw - going to penalties!");

                                // Random result between 0 and 1 decides penalty result (first come first serve)
                                double chance = decider.nextDouble();
                                if (chance > 0.5) {
                                    System.out.println("Match winner : " + teamA.getTeamName() + " (Penalties)");
                                    teamPointsMap.put(teamA.getTeamName(), teamPointsMap.get(teamA.getTeamName()) + 1); // Team
                                                                                                                        // A
                                                                                                                        // wins
                                                                                                                        // (penalties)
                                                                                                                        // -
                                                                                                                        // 1
                                                                                                                        // point
                                } else {
                                    System.out.println("Match winner : " + teamB.getTeamName() + " (Penalties)");
                                    teamPointsMap.put(teamB.getTeamName(), teamPointsMap.get(teamB.getTeamName()) + 1); // Team
                                                                                                                        // B
                                                                                                                        // wins
                                                                                                                        // (penalties)
                                                                                                                        // -
                                                                                                                        // 1
                                                                                                                        // point
                                }
                            }
                        }
                    }
                }
                System.out.println();
            }
        }

        // Table of team points
        System.out.println("Group Stage Results:");

        // look at each key-pair value from teamPointsMap and print out the point
        // entries (entry,getKey() etc)

        for (Map.Entry<String, Integer> entry : teamPointsMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue() + " points");
        }
    }

    public static void runTournament() {
        // NEEDS:
        // I need a list of teams ( parse squads array + shorten with getTeam)
        // I need a way of making a list of teams ( add teams from getTeam to array
        // list)
        // I need to shuffle these team matchups (collections.shuffle)
        // I need to divide these teams into 8 sets of 4

        // List of teams in group stage will be 32
        // List of lists? List interface (sublist from array of teams) 8x4

        ArrayList<Team> groupStageTeams = new ArrayList<>();

        // checking each squad index in squads arraylist
        // looking at populated squads only
        // getTeam method for each squad finds best players for each team
        // adding thhe team to groupstage arraylist
        for (Squad squad : squads) {
            if (squad != null) {
                // Get the team from the squad
                Team team = getTeam(squad);
                groupStageTeams.add(team);
            }
        }
        // Randomize matchups for matches
        Collections.shuffle(groupStageTeams);

        // Using the list interface to make a list of lists called groups
        List<List<Team>> groups = new ArrayList<>();
        for (int i = 0; i < 8; i++) {

            // indexes (if start = 0 , end index = 4 (+4 always))
            int startIndex = i * 4;
            int endIndex = startIndex + 4;

            // List<Team> group which allows me to create a sublist (temporary list) as
            // start and end indexes specified by the for loop logic.
            List<Team> group = groupStageTeams.subList(startIndex, endIndex);

            // Add current group sublist created from groupStageTeams to groups array list
            groups.add(new ArrayList<>(group));
        }

        for (int i = 0; i < groups.size(); i++) {
            System.out.println("Group: " + (i + 1));
            for (Team team : groups.get(i)) {
                System.out.println("Team: " + team.getTeamName());
                System.err.println();
            }
            // Simulate each match by group (see matchSimulation method for details)
            matchSimulation(groups.get(i));
        }

    }
}
