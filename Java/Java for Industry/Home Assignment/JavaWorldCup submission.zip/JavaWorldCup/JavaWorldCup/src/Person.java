public class Person {
    // 1) Initialise the properties of person
    private String firstName;
    private String surname;
    private String team;

    //2) Constructor to set the properties of person
    public Person (String firstName, String surname, String team){
        this.firstName = firstName;
        this.surname = surname;
        this.team = team;
    }

    // 3.1) Getter methods for the properties of person
    public String getFirstName(){
        return firstName;
    }

    public String getSurname(){
        return surname;
    }

    public String getTeam(){
        return team;
    }

    //3.2) Setter methods for the properties of person
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public void setSurname(String surname){
        this.surname = surname;
    }

    public void setTeam(String team){
        this.team = team;
    }



}
