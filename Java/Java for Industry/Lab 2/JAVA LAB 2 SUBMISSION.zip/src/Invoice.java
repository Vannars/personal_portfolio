public class Invoice {
    //public class with private initialisations for id decription quantity unitPrice and Paid to be used individually to the Invoice class;
    private int id;
    private String description;
    private int quantity;
    private double unitPrice;
    private boolean paid;
   // Constructor function Invoice with four arguments : id description quantity and unitPrice.
   // Paid is set to false by default.
   // This is available to be called to create a new Invoice instance
    Invoice(
    int id, 
    String description, 
    int quantity, 
    double unitPrice) {
   
        this.id = id;
        this.description = description;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.paid = false;

    }

    // Using overide and toString to properly format the output of Invoice in the console
    @Override 
    public String toString() {
    return String.format("Invoice[id=%d, description=%s, quantity=%d, unitPrice=%.2f, paid=%b]", id, description, quantity, unitPrice, paid);
}

//M set and get for paid
    public boolean getPaid(){
        return paid;
    }

    public void setPaid(boolean paid){
        this.paid = paid;
    }
}
