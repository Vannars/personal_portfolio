import java.security.SecureRandom;

public class Password {
    public static String generator(int length, int symbolNum, int digitCount) {
        StringBuilder password = new StringBuilder();
        SecureRandom randomNum = new SecureRandom();

        // These arrays store the numbers, symbols, and remaining characters
        char[] numbers = "1234567890".toCharArray();
        char[] symbols = "!£$%^&*()-_=+></?".toCharArray();
        char[] characters = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM".toCharArray();

        // Finding remaining count after digits and symbols have been generated
        int remainders = length - digitCount - symbolNum;

        // For generating numbers
        for (int i = 0; i < digitCount; i++) {
            char number = numbers[randomNum.nextInt(numbers.length)];
            password.append(number); // Adds to the end of the password
        }

        // For generating symbols
        for (int i = 0; i < symbolNum; i++) {
            char symbol = symbols[randomNum.nextInt(symbols.length)];
            password.append(symbol);
        }

        // For generating the remaining characters
        for (int i = 0; i < remainders; i++) {
            char character = characters[randomNum.nextInt(characters.length)];
            password.append(character);
        }

        // Rearranging the password
        // Starting from the end of the password working back
        for (int i = password.length() - 1; i > 0; i--) {
            // Random index made between a small range
            int index = randomNum.nextInt(i + 1);
            // Method for inserting a character at index
            char temp = password.charAt(index);
            // Sets the character at the random index to the character at i
            password.setCharAt(index, password.charAt(i));
            // Sets the character at i to the character at temp
            password.setCharAt(i, temp);
            // This effectively swaps the characters at the temp and random index around
        }

        return password.toString();

        

    }

        public static String validator(String password) {
        // Always have the length of the password
        int length = password.length();
        // Initialize counters and flags
        int symCount = 0;
        int numCount = 0;
        int charCount = 0;
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;

        // Iterate through each character of the password string array
        for (char i : password.toCharArray()) {
            // Increment the digit counter if it's a digit
            if (Character.isDigit(i)) {
                numCount++;
            // Increment the symbols counter if it's not a letter
            } else if (!Character.isLetter(i)) {
                symCount++;
            // Set upper case flag to true if it's uppercase
            } else if (Character.isUpperCase(i)) {
                hasUpperCase = true;
                charCount++;
            // Set lower case flag to true if it's lowercase
            } else if (Character.isLowerCase(i)) {
                hasLowerCase = true;
                charCount++;
            }
        }

        // true if there's a mix of upper and lower case characters
        boolean hasMixedUpperAndLowerCase = hasUpperCase && hasLowerCase;

        // Setting the conditions for different password qualities
        if (length <= 8 && symCount <= 1 && numCount <= 2 && !hasMixedUpperAndLowerCase) {
            return "Poor";
        } 
         if (length > 8 && symCount > 1 && numCount > 2 && !hasMixedUpperAndLowerCase) {
            return "ok";
        } 
        if (length > 12 && symCount > 3 && numCount > 3 && hasMixedUpperAndLowerCase) {
            return "Good";
        }
         if (length >= 16 && symCount > 4 && numCount > 4 && hasMixedUpperAndLowerCase) {
            return "Excellent";
        } else {
            return "invalid password";
        }
    }

}
