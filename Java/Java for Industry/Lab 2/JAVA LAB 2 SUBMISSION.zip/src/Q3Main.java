public class Q3Main {
    public static void main(String[] args) {
        // int length = 16;
        // int symbolNum = 4;
        // int digitCount = 3;

        // String examplePassword = Password.generator(length, symbolNum, digitCount);
        // System.out.println("Password: " + examplePassword);

         // Generate passwords using password class
         // array to hold passwords of length 5
         String[] key = new String[5];
         key[0] = Password.generator(6, 2, 1); // Example: poor
         key[1] = Password.generator(14, 4, 5); // Example: good
         key[2] = Password.generator(9, 2, 3); // Example: ok
         key[3] = Password.generator(9, 2, 2); // Example: poor 
         key[4] = Password.generator(18, 5, 6); // Example: excellent 
         
         // Validating and printing the quality of each password
         for (String password : key) {
             String validation = Password.validator(password);
             System.out.println("Password: " + password + " is " + validation);
         }
     }
}
