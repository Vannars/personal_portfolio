public class Q1Main {
    public static void main(String[] args) {
        // new instances using the contructor from Invoice
        Invoice exampleInvoice1 = new Invoice(42, "The Answer to Life the Universe and Everthing", 42, 42.0);
        Invoice exampleInvoice2 = new Invoice(1, "A basic invoice I suppose", 2, 10.0);
       // console output using toString() from the Public class Invoice to format the console output properly. 
        System.out.println(exampleInvoice1.toString());
        System.out.println(exampleInvoice2.toString());


    }
}
