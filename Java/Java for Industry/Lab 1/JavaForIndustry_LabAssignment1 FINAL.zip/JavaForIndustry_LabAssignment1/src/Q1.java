public class Q1 {
    public static void main(String[] args) {
        //write your code here to output the employee details
        int IdNumber = 12345; // integer for employee id
        String Name = "Jack Smith"; // string for employee name
        int Age = 52; // interger for employee age
        float Salary = 27736.80f; // float for salary (to include penny amounts)
        
        // Lines printing out in the system the employee details by calling my delcare variables
        System.out.println("Employee Reference");
        System.out.println("___________________");
        System.out.println("ID Number: " + IdNumber);
        System.out.println("Name: " + Name);
        System.out.println("Age: " + Age);
         System.out.println("Salary: " + String.format("%,.2f",Salary)); // formats the string with a % (comma) after 2 decimail places (.2f)
        
        int yearsToRetirement = 14; // he has 14 years until retirement
        float hourlyRate = ((Salary/52)/35); //his total salary divided into worked weeks, divided further into his hours per week ---> finds his hourly rate.
        System.out.println("Hourly Rate: " + String.format("%,.2f",hourlyRate)); // Prints his hourly rate to 2 decimal places
        System.out.println("Years To Retirement: "+ yearsToRetirement);
    }
}
