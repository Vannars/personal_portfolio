public class Q4 {
  public static void main(String[] args) throws java.io.IOException {
    //write your answer here
    // Setup for the main menu display
    String accounts = "1.  Current accounts";
    String credit = "2.  Credit cards";
    String loans = "3.  Loans";
    String savings = "4.  Savings accounts";

    // initialise variable to hold option selection
    char option;
    // initialise a conditional to check if menu selection is valid
    boolean invalidOption = false;
    // Prints out the main menu and conditions for selecting a menu 
    System.out.println("~~~~DIAL TONE ~~~~");
    System.out.println("Welcome to the operating service. We are pleased to take your call.");
    System.out.println("For Current Accounts, press 1. For Credit Cards, press 2. For Loans, press 3. For Savings Accounts, press 4.");
    System.out.println(accounts);
    System.out.println(credit);
    System.out.println(loans);
    System.out.println(savings);
    System.out.println("To hang up, press 'h'.");

    // DO WHILE loop will continue as long as "h" is not selected
   
    
    do {
      option = (char) System.in.read();
      //This if statement checks for newline and carriage return characters. This prevents extra messages in the console after pressing enter (multiple menu and error messaging etc)
      if (option == '\n' || option == '\r') {
        continue; // Skip
      }
      //switch statemmen with options 1-4, h and a default for validity checks
      switch (option) {
      case '1':
        System.out.println("Welcome to the Accounts Service");
        System.out.println("To hang up, press 'h'.");
        System.out.println();
        break;

      case '2':
        System.out.println("Welcome to the Credit Cards Service");
        System.out.println("To hang up, press 'h'.");
        System.out.println();
        break;

      case '3':
        System.out.println("Welcome to the Loans Service");
        System.out.println("To hang up, press 'h'.");
        System.out.println();
        break;

      case '4':
        System.out.println("Welcome to the Savings Accounts Service");
        System.out.println("To hang up, press 'h'.");
        System.out.println();
        break;

      case 'h':
        break; // Exit the loop when 'h' is entered - goto the end of do while loop

      default:
      // triggers only when a non menu input is entered
        if (!invalidOption) {
          invalidOption = true;
        }
        // invalid input initiates the main menu options with an error message
        if (invalidOption) {
          System.out.println("THE NUMBER YOU HAVE CHOSEN HAS NOT BEEN RECOGNISED. PLEASE TRY AGAIN.");
          System.out.println("For Current Accounts, press 1. For Credit Cards, press 2. For Loans, press 3. For Savings Accounts, press 4.");
          System.out.println(accounts);
          System.out.println(credit);
          System.out.println(loans);
          System.out.println(savings);
          System.out.println("To hang up, press 'h'.");
          System.out.println();
        }
      }
      //hangup when h is pressed
    } while (option != 'h');
    //closing message
    System.out.println("~~~~ CALL ENDED ~~~~");
  }
}