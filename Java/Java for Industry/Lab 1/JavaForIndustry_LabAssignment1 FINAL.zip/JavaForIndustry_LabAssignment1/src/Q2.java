public class Q2 {
    public static void main(String[] args) {
        //part 1: display even numbers between 1 and 100
        int x = 0; // int for even numbers
        int y = 0; // int for odd numbers
        int b = 0; // int for multiples of 4
        int a= 0; // int for "java" "script"

        // This while loop and if statement has conditions using iteration and modulus to print the even numbers from between 1 and 100
        System.out.println("Even Number between 1 and 100");
        while (x <= 100){
            x++;
            if( x%2 == 0){
            
                System.out.print(x + ", ");
            }
        }

        //part 2: display odd numbers between 1 and 100
        // This while loop and if statement has conditions using iteration and modulus to print the odd numbers from between 1 and 100
        System.out.println("");
        System.out.println("Odd numbers between 1 and 100");
        while (y < 100){
            y++;
            if(y%2 > 0){ 
                System.out.print(y + ", ");
            }
        }

        //part 3: display all the multiples of 4 between 1 and 100
        // This while loop and if statement has conditions using iteration and modulus to print the multiples of 4 numbers from between 1 and 100
        System.out.println("");
        System.out.println("Multiples of 4 between 1 and 100");
        while (b < 100){
            b++;
            if(b%4 == 0){
                System.out.print(b + ", ");
            }
        }


        //part 4: display all the numbers between 1 and 100 replacing multiples of 3 with Java
        //multiples of 5 with Script and multiples of 3 and 5 with JavaScript -- using iteration, modulus and conditionals
        System.out.println("");
        System.out.println("Multiples of 3 are Java, Multiples of 5 are Script and Multiples of 3&5 are JavaScript between 1 and 100");
        while(a <100){
            a++; // iteration on "a"

            // Print "Java" if "a" is a multiple of 3 not 5
            if ((a%3 == 0) && (a%5 > 0)) {
                System.out.println("Java");
            }

            //Print "Script" if "a" is a multiple of 5 not 3
            if ((a%3 > 0 ) && (a%5 == 0)) {
                System.out.println("Script");
            }

            //Print "JavaScript" if "a" is a multiple of both 3 and 5
            if((a%3 == 0) && (a%5 == 0)) {
                System.out.println("JavaScript");
            }

            //Print "a" as an integer if "a" is neither a multiple of 3 or 5 
            else if ((a%3 > 0) && (a%5 >0)) {
                System.out.println(a);
            }

        }

    
    }
}
