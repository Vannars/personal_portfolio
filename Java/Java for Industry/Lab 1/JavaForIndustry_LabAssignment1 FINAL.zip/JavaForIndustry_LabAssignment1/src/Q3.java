public class Q3 {
    public static void main(String[] args) {

        //write your code here to calculate the tax of the variable salary, make sure you try multiple values
        // to test your work

        // TESTING - using and array of values
        double testValues[] = {60000.00, 22000.00, 45000.00, 14500.00, 48342.32}; // an array to hold suggested testing values from the assesment sheet
        System.out.println("Test values:"); // heading for test values

        // this loop takes a value from text values and assigns it to testSalary which is fed into my taxCal method which calculate the taxable amount on that value
        for (double testSalary : testValues) {
            System.out.println("Total tax on salary: " + String.format("%,.2f", testSalary));
            taxCal(testSalary); // calls the taxCal method which takes the value of testSalary (in double form) as its argument.
            System.out.println(); // line spacing between each value, per loop
        }
    }

    // create a method for tax caluculations based on a double value for salary
    public static void taxCal(double salary) {
     // default tax value is 0%
        double tax = 0;

        // If salary is over 50000: find the excess amount above the tax bracket and multiply this iteratively by the tax rate until the lower limit of the tax bracket
        if (salary > 50000.00) {
            tax += (salary - 50000.00) * 0.40;
            //set the salary value for the next tax bracket
            salary = 50000.00;
        }
         // If salary is over 30000 && <= 50000: find the excess amount above the tax bracket and multiply this iteratively by the tax rate until the lower limit of the tax bracket
        if ((salary > 30000.00) && (salary <= 50000)) {
            tax += (salary - 30000.00) * 0.20;
            //set the salary value for the next tax bracket
            salary = 30000.00;
        }

        // If salary is over 15000: find the excess amount above the tax bracket and multiply this iteratively by the tax rate until the lower limit of the tax bracket
        if (salary > 15000.00) {
            tax += (salary - 15000.00) * 0.05;
            // stop here because theres no tax below 15000
        }
        System.out.print(String.format("%,.2f", tax)); // prints our tax correct to 2 decimal places
    }
}

