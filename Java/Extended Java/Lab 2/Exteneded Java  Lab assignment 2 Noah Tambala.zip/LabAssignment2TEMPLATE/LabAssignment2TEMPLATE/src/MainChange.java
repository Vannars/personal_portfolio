import java.util.*;

public class MainChange {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        boolean biggerPaid = false;

        double price = 0.00, paid= 0.00;

        while(!biggerPaid) {
            price = getMoneyInput("Enter the price in pounds and pence", in);
            paid = getMoneyInput("Enter the amount paid in pounds and pence", in);
            if(price > paid){
                System.out.println("You haven't paid enough!");
            }
            else{
                biggerPaid = true;
            }
        }

        System.out.println("price " + price);
        TreeMap<NotesAndCoins, Integer> changeComposition = calcChange(price, paid);
    
        for(NotesAndCoins n: changeComposition.keySet()){
            if(changeComposition.get(n) != 0){
                System.out.println(n.getName() + ": " + changeComposition.get(n));
            }
        }
        System.out.println();
        System.out.println("Amounts: 1");
        System.out.println(calcChange(price, paid));
        System.out.println();
    }

    //takes input from the user and ensures it is a double and returns a double with 2 decimal places
    //Question(String) is the prompt for user input and (in)scanner is collecting user input
    public static double getMoneyInput(String question, Scanner in){
        boolean validInput = false;
        double amount = 0.00;
        //do this until the user enters a valid double
        while(!validInput) {
            System.out.println(question);
            try {
                amount = in.nextDouble();
                validInput = true;
            }catch (InputMismatchException e){
                System.out.println("Invalid input try again");
                in.next();
            }
        }
        //return the value entered fixed to 2dp
        return (double)((int)(amount*100))/100;
    }

    public static TreeMap<NotesAndCoins, Integer> calcChange(double price, double paid){

        //COMPLETE THIS METHOD!!!
        //This method will return a TreeMap where the key is NotesAndCoins and the value is the number of each denomination to make up the change
        TreeMap<NotesAndCoins, Integer> tree = new TreeMap<>(Comparator.reverseOrder()); 
        
        double changeGiven  = paid - price;
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 
        
        int numOf50Notes = (int) (changeGiven / 50.00); //  divide the change given by the denomination 
        changeGiven -= (numOf50Notes * 50);
        tree.put(NotesAndCoins.POUND50, numOf50Notes);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf20Notes = (int) (changeGiven / 20.00);
        changeGiven -= (numOf20Notes * 20);
        tree.put(NotesAndCoins.POUND20, numOf20Notes);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf10Notes = (int) (changeGiven / 10.00);
        changeGiven -= (numOf10Notes * 10);
        tree.put(NotesAndCoins.POUND10, numOf10Notes);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf5Notes = (int) (changeGiven / 5.00);
        changeGiven -= (numOf5Notes * 5);
        tree.put(NotesAndCoins.POUND5, numOf5Notes);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf2Coins = (int) (changeGiven / 2.00);
        changeGiven -= numOf2Coins * 2;
        tree.put(NotesAndCoins.POUND2, numOf2Coins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf1Coins = (int) changeGiven;
        changeGiven -= numOf1Coins;
        tree.put(NotesAndCoins.POUND1, numOf1Coins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        // Coin calculations
        int numOf50pCoins = (int) (changeGiven / 0.50);
        changeGiven -= numOf50pCoins * 0.5;
        tree.put(NotesAndCoins.PENCE50, numOf50pCoins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf20pCoins = (int) (changeGiven / 0.2);
        changeGiven -= numOf20pCoins * 0.20;
        tree.put(NotesAndCoins.PENCE20, numOf20pCoins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf10pCoins = (int) (changeGiven / 0.10);
        changeGiven -= numOf10pCoins * 0.10;
        tree.put(NotesAndCoins.PENCE10, numOf10pCoins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf5pCoins = (int) (changeGiven / 0.05);
        changeGiven -= numOf5pCoins * 0.05;
        tree.put(NotesAndCoins.PENCE5, numOf5pCoins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf2pCoins = (int) (changeGiven / 0.02);
        changeGiven -= numOf2pCoins * 0.02;
        tree.put(NotesAndCoins.PENCE2, numOf2pCoins);
        changeGiven = Math.round(changeGiven * 100.00) / 100.00; 

        int numOf1pCoins = (int) (changeGiven / 0.01);
        tree.put(NotesAndCoins.PENCE1, numOf1pCoins);
        return tree;

    }


}

