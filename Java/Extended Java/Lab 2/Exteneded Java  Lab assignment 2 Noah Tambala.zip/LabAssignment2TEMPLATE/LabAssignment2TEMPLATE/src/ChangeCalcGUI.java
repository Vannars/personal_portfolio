import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ChangeCalcGUI extends JFrame implements ActionListener {
    // Plan - use a similar structure to Tip calculator for gui - flow layout, labels and buttons

    // Extend JLabel using NotesandCoins for Jlabels (saves time)
    public class NotesAndCoinsLabel extends JLabel {
        public NotesAndCoinsLabel(NotesAndCoins notesAndCoins) {
            super(notesAndCoins.getName()); // call parent notesAndCoins - (which is the NotesAndCoins class)
        }
    }

    NotesAndCoinsLabel pound50Label = new NotesAndCoinsLabel(NotesAndCoins.POUND50);
    NotesAndCoinsLabel pound20Label = new NotesAndCoinsLabel(NotesAndCoins.POUND20);
    NotesAndCoinsLabel pound10Label = new NotesAndCoinsLabel(NotesAndCoins.POUND10);
    NotesAndCoinsLabel pound5Label = new NotesAndCoinsLabel(NotesAndCoins.POUND5);
    NotesAndCoinsLabel pound2Label = new NotesAndCoinsLabel(NotesAndCoins.POUND2);
    NotesAndCoinsLabel pound1Label = new NotesAndCoinsLabel(NotesAndCoins.POUND1);
    NotesAndCoinsLabel pound50pLabel = new NotesAndCoinsLabel(NotesAndCoins.PENCE50);
    NotesAndCoinsLabel pound20pLabel = new NotesAndCoinsLabel(NotesAndCoins.PENCE20);
    NotesAndCoinsLabel pound10pLabel = new NotesAndCoinsLabel(NotesAndCoins.PENCE10);
    NotesAndCoinsLabel pound5pLabel = new NotesAndCoinsLabel(NotesAndCoins.PENCE5);
    NotesAndCoinsLabel pound2pLabel = new NotesAndCoinsLabel(NotesAndCoins.PENCE2);
    NotesAndCoinsLabel pence1Label = new NotesAndCoinsLabel(NotesAndCoins.PENCE1);


    // These are my labels
    JLabel priceLabel = new JLabel("Enter the price in pounds and pence");
    JLabel paidLabel = new JLabel("Enter the amount paid in  pounds and pence");
    JLabel resultsLabel = new JLabel(" ");
    JButton enterButton = new JButton("Enter");

    // TEXTFIELDS - template I made from tip Caldulator
    private static JTextField UniformTextField() { // template for textfields
        JTextField textField = new JTextField();
        // Preferred size for all text fields
        textField.setPreferredSize(new Dimension(150, 40));
        return textField;
    }

    JTextField priceField = UniformTextField(); // price textfield
    JTextField paidField = UniformTextField(); // paid textfield

    ChangeCalcGUI() {
        // Setting parameters for the Jframe
        this.setSize(300, 400); // set dimentions of the frame
        this.setTitle("Change Calculator"); // set frame title
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // set closing operations
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 20));

        // Setting Components to go inside the frame
        this.enterButton.addActionListener(this);

        // LABELS, FIELDS, BUTTONS
        this.add(priceLabel);
        this.add(priceField);

        this.add(paidLabel);
        this.add(paidField);


        this.add(enterButton);
        this.add(resultsLabel);

        // misc organising - set visible
        this.setResizable(false);
        this.setVisible(true); // allows JFrame visibility
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // LOGIC FOR ACTION PERFORMED 
        if (e.getSource() == enterButton) {
             // take my field entries and set these to be used as price and paid values
             double price = Double.parseDouble(priceField.getText());
             double paid = Double.parseDouble(paidField.getText());

            
             if (((price < 0.0 && paidField.getText() == null) || ( paid < 0.00 && priceField.getText() == null))) {
                resultsLabel.setText("Error: Empty field an negative entires!");
                return;

            } else if ( price < 0.00  || paid < 0.00){
               
                resultsLabel.setText("Error: Negative Field entries!");
                return;

            } else if(priceField.getText() == null || paidField.getText() == null){
               resultsLabel.setText("Error: Empty Fields!");
               return;
            
            } else {
           
            // call a new instance of the main class
            // use this main class to create a new treemap taking the values of price and paid (set above)
            MainChange mainChange = new MainChange();
            TreeMap<NotesAndCoins, Integer> changeAmount = mainChange.calcChange(price, paid);

            // Difficult - string builder to show results text - loop over the keyset on each enum of NotesAndCOins 
            StringBuilder resultsText = new StringBuilder("<html>Change given by Denomination:<br>"); // Part of results (html open tags - html for loop)
            for (NotesAndCoins n : changeAmount.keySet()) {
                if (changeAmount.get(n) != 0) { //ensure we have an enum value
                    // use append to build the string - n.getName() (enum string name) - append a separator - append a the current change amount from n - append a line break
                    resultsText.append(n.getName()).append(": ").append(changeAmount.get(n)).append("<br>");
                }
            }
            // close html
            resultsText.append("</html>");
            //update results label - to String
            resultsLabel.setText(resultsText.toString());

        };
    };
    }

    public static void main(String[] args) {

        ChangeCalcGUI changeCalcGUI = new ChangeCalcGUI();
    }
}
