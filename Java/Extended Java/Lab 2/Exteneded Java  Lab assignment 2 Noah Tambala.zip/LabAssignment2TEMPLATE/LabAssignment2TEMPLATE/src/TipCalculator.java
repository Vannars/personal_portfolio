import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class TipCalculator extends JFrame implements ActionListener {

    // LABELS
    JLabel priceLabel = new JLabel("Price £"); // price label
    JLabel tipLabel = new JLabel("tip (%)"); // tip label
    JLabel peopleLabel = new JLabel("People"); // people label;
    String dividedCost =" ";
    JLabel toPayEach = new JLabel("Each person should pay £"); // people label;;

    // TEXTFIELDS
    private static JTextField UniformTextField() { // template for textfields
        JTextField textField = new JTextField();
        // Preferred size for all text fields
        textField.setPreferredSize(new Dimension(150, 60));
        return textField;
    }

    JTextField priceField = UniformTextField(); // price textfield
    JTextField tipField = UniformTextField(); // tip textfield
    JTextField peopleField = UniformTextField(); // people

    // BUTTON
    JButton calculateButton = new JButton("Calculate"); // calculate button

    TipCalculator() {
        // Setting parameters for the Jframe
        this.setSize(250, 500); // set dimentions of the frame
        this.setTitle("Tip Calculator"); // set frame title
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // set closing operations
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));


        // Setting Components to go inside the frame
        calculateButton.addActionListener(this);

        // Adding components to the frame;

        // PRICE
        this.add(priceLabel);
        this.add(priceField);
        this.tipField.setText("10.00");

        // TIP
        this.add(tipLabel);
        this.add(tipField);
        this.tipField.setText("0");

        // PEOPLE
        this.add(peopleLabel);
        this.add(peopleField);
        this.peopleField.setText("1");

        // BUTTON
        this.add(calculateButton);

        // TOTAL
        this.add(toPayEach);

        // misc organising
        this.setResizable(true);
        this.setVisible(true); // allows JFrame visibility
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calculateButton){
            double total = 0.0;
            int tip = 0;
            double price = 0.0;
            int people = 0;
            String temp;

            try {
                temp = priceField.getText(); // take the text from the field
                if (temp != null && !temp.trim().isEmpty()) { // check the text exists 
                    price = Double.parseDouble(temp); // parse the correct primitive type
                    total = total + price; // add to the total
                } else { // error handling
                    toPayEach.setText("Price isn't a double. Try again!");
                    System.err.println("Invalid Price input. Input a double");
                    return; // stop further processing on err
                }

                if (temp != null && !temp.trim().isEmpty()) { // repeat process as above
                    temp = tipField.getText();
                    tip = Integer.parseInt(temp); 
                    double doubleTip = (double) tip; //convert primitive int to doubl
                    total += (tip != 0) ? price * (doubleTip / 100.0) : 0; // Add tip to the total
                } else { //error handling
                    toPayEach.setText("Tip isn't an integer. Try again!");
                    System.err.println("Invalid Tip input. Input an integer");
                    return; //stop further processing on err
                }

                if (temp != null && !temp.trim().isEmpty()) { // repeat process as above
                    temp = peopleField.getText();
                    people = Integer.parseInt(temp);
                    double doublePeople = (double) people; //primitive conversions
                    total /= (doublePeople != 0) ? doublePeople : 1;
                } else { // error hadling 
                    toPayEach.setText("Input an integer into the people field. Try again!");
                    System.err.println("Invalid People input. Input an integer ");
                    return; //stop further processing on err
                }

                if (total >= 0.0) { // conditional for presening total
                    System.out.println("Total to pay: " + (String.format("%.2f", total)));
                    dividedCost = String.format("%.2f", total);
                    toPayEach.setText("Amount to Pay: £" + dividedCost); // set text in text label
                } else { //error handling
                    toPayEach.setText("Check input and try again");
                    System.err.println("Cannot include negative numbers (wouldnt that be nice?)");
                    return;
                }

                // Error handling needs some work - otherwise a functional tip calculator .
            } catch (NumberFormatException ex) { 
                //Other error handling
                toPayEach.setText("Check input and try again");
                System.err.println("Enter price, tip and people values valid numbers.");
            }
        }
    }

    public static void main(String[] args) {
        TipCalculator tipCalculator = new TipCalculator(); // runs the Jfram using the TipCalculator class 
    }
}
