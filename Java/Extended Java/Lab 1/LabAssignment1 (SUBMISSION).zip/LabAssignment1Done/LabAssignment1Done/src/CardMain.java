public class CardMain {
    public static void main(String[] args) {
        Deck d = new Deck(true);

        System.out.println();
        System.out.println("DECK:");
        System.out.println(d);

       Hand h = new Hand();
       for(int i = 0; i<5; i++) {
           h.addCard(d.deal());
       }
       System.out.println();
       System.out.println("HAND:");
       System.out.println(h);
       System.out.println(h.getHandRank());
       System.out.println();

       // ROYAL FLUSH 
       System.out.println("ROYAL FLUSH TEST");
       System.out.println("----------------------------------------------------------------------------------------------------------");
       Deck d2 = new Deck(true);
       System.out.println();
       System.out.println("DECK:");
       System.out.println(d2);
       Hand rF = new Hand();
       rF.addCard(d2.dealSpecificCard("10", "Hearts"));
       rF.addCard(d2.dealSpecificCard("J", "Hearts"));
       rF.addCard(d2.dealSpecificCard("K", "Hearts"));
       rF.addCard(d2.dealSpecificCard("Q", "Hearts"));
       rF.addCard(d2.dealSpecificCard("A", "Hearts"));
       System.out.println();
       System.out.println("HAND:");
       System.out.println(rF);
       System.out.println("Cards Rank: " + rF.getHandRank());
       System.out.println();

         // STRAIGHT FLUSH
        System.out.println("STRAIGHT FLUSH TEST");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        Deck d3 = new Deck(true);
        System.out.println();
        System.out.println("DECK:");
        System.out.println(d3);

        Hand sF = new Hand();
        sF.addCard(d3.dealSpecificCard("6", "Hearts"));
        sF.addCard(d3.dealSpecificCard("7", "Hearts"));
        sF.addCard(d3.dealSpecificCard("8", "Hearts"));
        sF.addCard(d3.dealSpecificCard("9", "Hearts"));
        sF.addCard(d3.dealSpecificCard("10", "Hearts")); 
        System.out.println();
        System.out.println("HAND:");
        System.out.println(sF);
        System.out.println("Cards Rank: " + sF.getHandRank());
        System.out.println();
       
       // FOUR OF A KIND
        System.out.println("FOUR OF A KIND TEST");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        Deck d4 = new Deck(true);
        System.out.println();
        System.out.println("DECK:");
        System.out.println(d4);

        Hand fOAK = new Hand();
        
        fOAK.addCard(d4.dealSpecificCard("8", "Hearts"));
        fOAK.addCard(d4.dealSpecificCard("8", "Diamonds"));
        fOAK.addCard(d4.dealSpecificCard("8", "Clubs"));
        fOAK.addCard(d4.dealSpecificCard("8", "Spades"));
        fOAK.addCard(d4.dealSpecificCard("9", "Hearts"));
        System.out.println();
        System.out.println("HAND:");
        System.out.println(fOAK);
        System.out.println("Cards Rank: " + fOAK.getHandRank());
        System.out.println();


         //FULL HOUSE
         System.out.println("FULL HOUSE TEST");
         System.out.println("----------------------------------------------------------------------------------------------------------");
         Deck d5 = new Deck(true);
         System.out.println();
         System.out.println("DECK:");
         System.out.println(d5);
 
         Hand fH = new Hand();
         fH.addCard(d5.dealSpecificCard("2", "Diamonds"));
         fH.addCard(d5.dealSpecificCard("2", "Spades"));
         fH.addCard(d5.dealSpecificCard("2", "Hearts"));
         fH.addCard(d5.dealSpecificCard("8", "Clubs"));
         fH.addCard(d5.dealSpecificCard("8", "Hearts")); 
         System.out.println();
         System.out.println("HAND:");
         System.out.println(fH);
         System.out.println("Cards Rank: " + fH.getHandRank());
         System.out.println();

          //FLUSH TEST
          System.out.println("FLUSH TEST");
          System.out.println("----------------------------------------------------------------------------------------------------------");
          Deck d6 = new Deck(true);
          System.out.println();
          System.out.println("DECK:");
          System.out.println(d6);
  
          Hand f = new Hand();
          f.addCard(d6.dealSpecificCard("3", "Hearts"));
          f.addCard(d6.dealSpecificCard("7", "Hearts"));
          f.addCard(d6.dealSpecificCard("2", "Hearts"));
          f.addCard(d6.dealSpecificCard("J", "Hearts"));
          f.addCard(d6.dealSpecificCard("K", "Hearts")); 
          System.out.println();
          System.out.println("HAND:");
          System.out.println(f);
          System.out.println("Cards Rank: " + f.getHandRank());
          System.out.println();


          //STRAIGHT TEST
          System.out.println("STRAIGHT TEST");
          System.out.println("----------------------------------------------------------------------------------------------------------");
          Deck d7 = new Deck(true);
          System.out.println();
          System.out.println("DECK:");
          System.out.println(d7);
  
          Hand s = new Hand();
          s.addCard(d7.dealSpecificCard("6", "Hearts"));
          s.addCard(d7.dealSpecificCard("7", "Clubs"));
          s.addCard(d7.dealSpecificCard("8", "Hearts"));
          s.addCard(d7.dealSpecificCard("9", "Diamonds"));
          s.addCard(d7.dealSpecificCard("10", "Spades")); 
          System.out.println();
          System.out.println("HAND:");
          System.out.println(s);
          System.out.println("Cards Rank: " + s.getHandRank());
          System.out.println();


          //THREE OF A KIND TEST
          System.out.println("THREE OF A KIND TEST");
          System.out.println("----------------------------------------------------------------------------------------------------------");
          Deck d8 = new Deck(true);
          System.out.println();
          System.out.println("DECK:");
          System.out.println(d8);
  
          Hand tOAK = new Hand();
          tOAK.addCard(d8.dealSpecificCard("2", "Diamonds"));
          tOAK.addCard(d8.dealSpecificCard("2", "Spades"));
          tOAK.addCard(d8.dealSpecificCard("2", "Hearts"));
          tOAK.addCard(d8.dealSpecificCard("K", "Clubs"));
          tOAK.addCard(d8.dealSpecificCard("8", "Hearts")); 
          System.out.println();
          System.out.println("HAND:");
          System.out.println(tOAK);
          System.out.println("Cards Rank: " + tOAK.getHandRank());
          System.out.println();


          //TWO PAIRS TEST
          System.out.println("TWO PAITS TEST");
          System.out.println("----------------------------------------------------------------------------------------------------------");
          Deck d9 = new Deck(true);
          System.out.println();
          System.out.println("DECK:");
          System.out.println(d9);
  
          Hand tP = new Hand();
          tP.addCard(d9.dealSpecificCard("10", "Diamonds"));
          tP.addCard(d9.dealSpecificCard("10", "Spades"));
          tP.addCard(d9.dealSpecificCard("5", "Hearts"));
          tP.addCard(d9.dealSpecificCard("5", "Clubs"));
          tP.addCard(d9.dealSpecificCard("3", "Hearts")); 
          System.out.println();
          System.out.println("HAND:");
          System.out.println(tP);
          System.out.println("Cards Rank: " + tP.getHandRank());
          System.out.println();


          //ONE PAIR TEST
          System.out.println("ONE PAIR TEST");
          System.out.println("----------------------------------------------------------------------------------------------------------");
          Deck d10 = new Deck(true);
          System.out.println();
          System.out.println("DECK:");
          System.out.println(d10);
  
          Hand oP = new Hand();
          oP.addCard(d10.dealSpecificCard("7", "Diamonds"));
          oP.addCard(d10.dealSpecificCard("7", "Spades"));
          oP.addCard(d10.dealSpecificCard("5", "Hearts"));
          oP.addCard(d10.dealSpecificCard("6", "Clubs"));
          oP.addCard(d10.dealSpecificCard("3", "Diamonds")); 
          System.out.println();
          System.out.println("HAND:");
          System.out.println(oP);
          System.out.println("Cards Rank: " + oP.getHandRank());
          System.out.println();


          //HIGH CARD TEST
          System.out.println("HIGH CARD TEST");
          System.out.println("----------------------------------------------------------------------------------------------------------");
          Deck d11 = new Deck(true);
          System.out.println();
          System.out.println("DECK:");
          System.out.println(d11);
  
          Hand hC = new Hand();
          hC.addCard(d11.dealSpecificCard("7", "Diamonds"));
          hC.addCard(d11.dealSpecificCard("8", "Spades"));
          hC.addCard(d11.dealSpecificCard("5", "Hearts"));
          hC.addCard(d11.dealSpecificCard("J", "Clubs"));
          hC.addCard(d11.dealSpecificCard("K", "Hearts")); 
          System.out.println();
          System.out.println("HAND:");
          System.out.println(hC);
          System.out.println("Cards Rank: " + hC.getHandRank());
          System.out.println();
 
    }
}
