import java.util.ArrayList;

public class BookMain {
    public static void main(String[] args) {
        BookCollection bCollection = new BookCollection("LabAssignment1Done/BookList.csv");
        // Get the list of book
        System.out.println("PRINT BOOKS");
        bCollection.printBookList();
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        // Print details of long books
        System.out.println("PRINT LONG BOOKS");
        for (Book book : bCollection.getLongBooks()) {
            System.out.println("Title: [" + book.getTitle() + "], Pages: " + book.getPages());
        }
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        //Print out authors
        System.out.println("PRINT OUT AUTHORS");
        for(String author : bCollection.getAuthors() ){
            System.out.print("["+author+"] ");
        }
        System.out.println();
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        //Searching for a book by title
        System.out.println("SEARCH FOR A BOOK BY TITLE");
        String search = "The Great Gatsby";
        System.out.println("Book: [" + bCollection.getBookByTitle(search).getTitle() + " by " + bCollection.getBookByTitle(search).getAuthor() + "] is the book you searched for.");
        System.out.println("Edit the search term in BookMain.java to search again");

        System.out.println();
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        // Print out top 10 popular books
        System.out.println("TOP 10 MOST POPULAR BOOKS");
        for(Book book: bCollection.mostPopular()){
            System.out.println("Book: [" + book.getTitle()+ " By " + book.getAuthor() + "] Copies on Loan: " + book.getCopiesOnLoan());
        }
    }

}
