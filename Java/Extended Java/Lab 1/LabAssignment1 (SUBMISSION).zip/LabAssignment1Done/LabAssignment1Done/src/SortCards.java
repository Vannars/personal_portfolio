import java.util.Comparator;

public class SortCards implements Comparator<Card> {
    @Override
    public int compare(Card o1, Card o2) {

        int a = o1.getNumericValue(); //getNumericValue converts the 
        int b = o2.getNumericValue(); //String value of each card to an integer

        if (a > b) { // Where o1 has a higher value property than o2 return 1.
            return 1;
        } else if (a < b) { // Where o1 has a lower value property than o2 return -1;
            return -1;
        } else //Where both o1 = o2 (numerical values)
        return 0;// return 0
    }
}


