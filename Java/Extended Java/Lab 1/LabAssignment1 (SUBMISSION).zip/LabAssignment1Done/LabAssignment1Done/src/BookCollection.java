import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.ArrayList;

public class BookCollection {
    private ArrayList<Book> books = new ArrayList<Book>();

    // 2, complete constructor that takes a string path (the BookList file name)
    // load the books from BookList into the books arrayList
    // When complete books should have 100 items. Make sure you don't include the
    // header row!
    BookCollection(String path) {

        String filePath = path; // refers to string path (which can take an inserted filePath)

        try {
            // Creating the scanner for reading the file
            Scanner s = new Scanner(new File(filePath), "UTF-8"); // Specify UTF-8 encoding
            s.nextLine(); // skip the header

            while (s.hasNextLine()) { // Checking each line
                String line = s.nextLine().trim(); // defines individual lines
                String[] bookData = line.split(","); // splits data into an array to be read (creating book object)

                // Define array data positions to define property values (to be used in creating
                // a book object)
                String title = (bookData[0].trim());
                String author = (bookData[1].trim());
                long isbn = (Long.parseLong(bookData[2].trim()));
                int pages = (Integer.parseInt(bookData[3].trim()));
                int copiesInCollection = (Integer.parseInt(bookData[4].trim()));
                int CopiesOnLoan = (Integer.parseInt(bookData[5].trim()));

                // Using the above values make a new book
                Book book = new Book(title, author, isbn, pages, copiesInCollection, CopiesOnLoan);

                // Add book to books arrayList
                books.add(book);
            }
            s.close(); // scanner closes here
        } catch (FileNotFoundException e) {

            System.out.println("File Not Found"); // just in case csv isnt readable
        }

    }

    public void printBookList() { // testing function
        for (Book book : books) { // check every book object in books array list
            // Print out to console the book details
            System.out.println("Title: " + book.getTitle());
            System.out.println("Author: " + book.getAuthor());
            System.out.println("ISBN: " + book.getIsbn());
            System.out.println("Pages: " + book.getPages());
            System.out.println("Copies in Collection: " + book.getCopiesInCollection());
            System.out.println("Copies on Loan: " + book.getCopiesOnLoan());
            System.out.println("------------------------");
        }
    }

    // 3, Return a HashSet of all the authors in the book list
    public HashSet<String> getAuthors() {
        HashSet<String> authorSet = new HashSet<String>();
        String author = "";
        for (Book book : books) {
            if (!authorSet.contains(book.getAuthor())) {
                author = book.getAuthor();
                authorSet.add(author);
            }
        }
        return (HashSet<String>) authorSet;

    }

    // 4, return an arrayList of books with more than 750 pages
    public ArrayList<Book> getLongBooks() {

        ArrayList<Book> longBooks = new ArrayList<>(); // this new list will store only long books
        for (Book book : books) { // check every book object in the main books list
            int threshold = 750;
            if (book.getPages() > threshold) { // if book has > 750 pages
                longBooks.add(book); // it gets added to the long books list
            }
        }
        return longBooks; // final (potentially) populated longBooks list
    }

    // 5, return the book if the given title is in the list.
    public Book getBookByTitle(String title) {
        Book specificBook; // placeholder empty book
        for (Book book : books) { // check book objects
            if (book.getTitle().equals(title)) { // if book title matches searched title
                specificBook = book; // placholder is now equavalent to book
                return specificBook; // return the specified (searched for) book
            }
        }
        specificBook = null; // only null if book isnt found
        return specificBook; // null is returned if book is not found
    }

    // 6, return an array of the 10 most popular books (That is those that currently
    // have most copies on loan)
    public Book[] mostPopular() {
        int popSize = 10;
        Book[] mostPoplarBooks = new Book[popSize]; // new book array with size 10
        books.sort((bookA, bookB) -> Integer.compare(bookB.getCopiesOnLoan(), bookA.getCopiesOnLoan())); // sort by
                                                                                                         // comparison
                                                                                                         // of copies on                                                                                                         // loan
        for (int i = 0; i < popSize; i++) { // this loop populates based on 
            mostPoplarBooks[i] = books.get(i);
        }
        return mostPoplarBooks;

    }
}
