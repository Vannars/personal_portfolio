public class Book {
    private String title;
    private String author;
    private long isbn;
    private int pages;
    private int copiesInCollection;
    private int CopiesOnLoan;

    // 1, complete this class with a constructor that has arguments for all the
    // properties
    // and, getters and setters for each of them

    public Book(String title, String author, long isbn, int pages, int copiesInCollection, int CopiesOnLoan) {
        this.title=title;
        this.author=author;
        this.isbn=isbn;
        this.pages=pages;
        this.copiesInCollection=copiesInCollection;
        this.CopiesOnLoan=CopiesOnLoan;
    }

    // getters
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;

    }

    public long getIsbn() {
        return isbn;

    }

    public int getPages() {
        return pages;
    }

    public int getCopiesInCollection() {
        return copiesInCollection;
    }

    public int getCopiesOnLoan() {
        return CopiesOnLoan;
    }

    // setters
    public static void setTitle(String t) {
        String title = t;
    }

    public static void setAuthor(String a) {
        String author = a;
    }

    public static void setIsbn(long i) {
        long isbn = i;
    }

    public static void setPages(int p) {
        int pages = p;
    }

    public static void setCopiesInCollection(int c) {
        int copiesInCollection = c;

    }

    public static void setCopiesOnLoan(int c) {
        int CopiesOnLoan = c;
    }

}
