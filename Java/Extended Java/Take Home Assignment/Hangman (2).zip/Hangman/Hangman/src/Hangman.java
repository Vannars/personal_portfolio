import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Hangman {
    //RUN PROGRAME FROM MAIN 

    // INHERENT TRAITS
    private String word; // new word
    private char[] wordArray; // array made from the content of the new word
    private char[] progressArray; // This array holds the current state of the guessed word

    private Set<Character> guesses; // This set holds the characters of the attempts
    private boolean correctGuess; // Tracks if the guess was correct
    private int attempts; // Default value of the attempts or lives
    private int wordsGuessed;

    public static Scanner sc = new Scanner(System.in);

    // HANGMAN SETUP - WORD RESETTING - PROGRESS TRACKING
    public Hangman(int attempts) {
        resetWord(attempts);
        this.attempts = attempts;
    }

    private void resetWord(int attempts) {
        this.word = Main.getWord().toUpperCase();
        this.wordArray = word.toCharArray();
        // Empty word case
        if (word == null || word.isEmpty()) {
            System.err.println("Error: No words available to start the game.");
            return;
        }
        // Make an array that matches the length of the new word and fill it with
        // placeholders
        this.progressArray = new char[wordArray.length]; // New array specific to the length of the new word
        Arrays.fill(progressArray, '_'); // Placeholder values
        // Store the guesses
        this.guesses = new HashSet<>();
        this.attempts = attempts;
    }

    // GETTERS - VARIOUS
    public String getCurrentWord() {
        return word;
    }

    public int getAttempts() {
        return attempts;
    }

    public int getWordsGuessed() {
        return wordsGuessed;
    }

    public int setWordsGuessed(int n) {
        wordsGuessed = n;
        return wordsGuessed;
    }
    public String getCurrentProgress() {
        return String.valueOf(progressArray);
    }

    // GUESS PROCESSING - BACKEND CONDITIONS AND LOOPS
    public boolean guessProcess(char guessChar) {
        // Has this guess been made before?
        if (guesses.contains(guessChar)) {
            return true;
        }
        // Has not been made? Add the guess character to the list
        guesses.add(guessChar);
        correctGuess = false; // lets assume you got it wrong

        // Let's check if the word (in the word array) has this character
        for (int i = 0; i < wordArray.length; i++) {
            if (wordArray[i] == guessChar) {
                progressArray[i] = guessChar;
                correctGuess = true; // lets set it to true if it is in the array
            }
        }
        // Was the guess incorrect at this stage? Subtract from the attempts
        if (!correctGuess) {
            if (attempts == 0) {
                // If attempts are zero
                return false;
            }
            attempts--;
        }

        if (hasWon()) {
            wordsGuessed++;
        }
        return correctGuess;
    }

    public void resetGame(int initialAttempts) {
        // Reset the word when the player wins
        resetWord(initialAttempts);
    }

    public boolean hasWon() { // compare the answer with the word
        return Arrays.equals(progressArray, wordArray);

    }

    public boolean hasLost() {
        return attempts <= 0;
    }
}
