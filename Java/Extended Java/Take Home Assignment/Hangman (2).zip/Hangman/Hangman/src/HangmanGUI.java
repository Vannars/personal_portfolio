import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.HashSet;
import java.util.Set;

public class HangmanGUI extends JFrame implements ActionListener {
    // RUN PROGRAMME FROM MAIN

    // INITIAL DECLARATIONS OF FIELDS/LABELS/SETS
    private Hangman hangman;
    // These Jlabels are used within the Jframe that will run this game
    private JLabel guessLabel = new JLabel("Guess:"); // will indicate where to input a guess
    private JLabel wordProgressLabel = new JLabel(); // will show the progress so far

    private JTextField guessTextField = new JTextField(10); // this text field will be used to input a guess
    private JButton submitGuessButton = new JButton("Submit Guess"); // this button will be used to submit a guess

    private JLabel attemptsLabel = new JLabel("Attempts remaining:"); // Label will show remaining attempts
    private JLabel incorrectGuessesLabel = new JLabel("Incorrect guesses:"); // Label will show incorrect guesses
    private JLabel wordsGuessedLabel = new JLabel("Words guessed:"); // Label will show incorrect guesses

    private Set<Character> incorrectGuesses = new HashSet<>(); // stores the incorrect guesses - to be retrieved

    private TimeAttack timer;
    private Thread timerThread;
    private JLabel timerLabel = new JLabel("Time remaining: ");

    // GUI SETUP
    public HangmanGUI(int attempts) {
        this.hangman = new Hangman(attempts); // new instance of hangman class - initialises the game
        this.timer = new TimeAttack(this, 60);
        // with the initial labelling
        wordProgressLabel.setText("Word: " + hangman.getCurrentProgress());
        attemptsLabel.setText("Attempts remaining: " + hangman.getAttempts());
        incorrectGuessesLabel.setText("Incorrect guesses: ");
        wordsGuessedLabel.setText("Words Guessed " + hangman.getWordsGuessed());

        // General window settings
        setSize(600, 450);
        setResizable(false);
        setTitle("Hangman Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2)); // Adjust layout for better organization

        // add labels etc
        add(guessLabel);
        add(guessTextField);
        add(submitGuessButton);
        add(wordProgressLabel);
        add(attemptsLabel);
        add(incorrectGuessesLabel);
        add(wordsGuessedLabel);
        add(timerLabel);

        // interactivity fom the listener
        submitGuessButton.addActionListener(this);
        // submit button not strictly needed - enter button will work too
        guessTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    processGuess(); // Call the method to process the guess when Enter is pressed
                }
            }
        });
        setVisible(true); // dontforgethis ;)
        startTimer(); // countdown game setting

    }

    // ACTION LISTENER IMPLEMENTAITON
    @Override
    public void actionPerformed(ActionEvent e) {
        // Okay so this is linked to submitGuessButton
        // It will processGuess() using the input from the GuessTextfield
        if (e.getSource() == submitGuessButton) {
            processGuess();
        }
    }

    // INPUT PROCESSING (PASSING TO GUESS PROCESSING IN Hangman.java)

    // As it sounds - processes the input - but lets break it down
    private void processGuess() {

        // We take the guess from the textfield, standardise it as user input and
        // REMOVE* the characters in the textfield (for new input you see)
        String userInput = guessTextField.getText().toUpperCase().trim();
        guessTextField.setText(""); // *

        // Next we make sure that we have only a SINGLE character entered at a time in
        // the if statement below
        if (userInput.length() == 1 && Character.isLetter(userInput.charAt(0))) {
            char guessChar = userInput.charAt(0);
            boolean correctGuess = hangman.guessProcess(guessChar); // this will check if we have guessed correctly (SEE
                                                                    // hangman guessProcess for this)

            // If we get it wrong
            if (!correctGuess) {
                incorrectGuesses.add(guessChar); // added to list of bad guesses :(
                incorrectGuessesLabel.setText("Incorrect guesses: " + incorrectGuesses.toString().toUpperCase());

                if (hangman.getAttempts() > 0) {
                    // If attempts > 0 keep timer keeps going
                    guessTextField.requestFocus();
                    return;
                }
            }

            // If we made it this far Case 1 - we lose atttempts - Case 2 Nothing changes
            attemptsLabel.setText("Attempts remaining: " + hangman.getAttempts());
            wordProgressLabel.setText("Word: " + hangman.getCurrentProgress()); // Progress is tracked here - again see
                                                                                // hangman for the backend of this

            // Update the label of guesses
            wordsGuessedLabel.setText(("WordsGuessed: " + hangman.getWordsGuessed()));

            // END STATE CONDITIONS
            // Case 1 - If you win this will pop up
            if (hangman.hasWon()) {
                JOptionPane.showMessageDialog(this, "You guessed " + hangman.getCurrentProgress(),
                        "You win!", JOptionPane.INFORMATION_MESSAGE);
                resetGame(); // Timeattack settings might prevent tthe dialoge box
                // Case 2 - if you lose this will happen
            } else if (hangman.hasLost()) {
                JOptionPane.showMessageDialog(this,
                        "Better luck next time! The word you were looking for was: " + hangman.getCurrentWord(),
                        "Game Over :( ", JOptionPane.ERROR_MESSAGE);
                resetGame(); // The main difference is the word count resets - otherwise default (timeattack)
                                    // settings will be run.
            }

        } else {
            JOptionPane.showMessageDialog(this, "Hmph, that input looks wrong...please enter a letter from A - Z only!",
                    "Toastie!", JOptionPane.WARNING_MESSAGE);
        }
        guessTextField.requestFocus();
    }

    ////NOTES ABOUT THIS SECTION: I probabaly could have made this more modular at points. 
    // My way of thinking was developing this to react directly with the GUI, but there were issues:
    //For instance the relabeling focus of reset game() felt like it belonged in the GUI class
    //The thread timer is accounted for in the console, so the tracking here felt better grouped with its gui component
    
    private void resetGame() {
        // Reset the hangman game with the desired initial attempts
        // Stop the previous timer
        if (timerThread != null && timerThread.isAlive()) {
            timer.end();
            try {
                timerThread.join(); // Wait for the thread to terminate
            } catch (InterruptedException e) {
                e.printStackTrace(); // Handle or log the exception as needed
            }
            if (!hangman.hasWon()) {
                hangman.setWordsGuessed(0);
            }
        }
        hangman.resetGame(5); // Pass the initial attempts as an argument (e.g., 5)
        // Create new TimeAttack instance and start the timer
        timer = new TimeAttack(this, 60);
        timerThread = new Thread(timer);
        timerThread.start();
        // Reset GUI labels/fields
        wordsGuessedLabel.setText("WordsGuessed: " + hangman.getWordsGuessed());
        incorrectGuesses.clear();
        wordProgressLabel.setText("Word: " + hangman.getCurrentProgress());
        attemptsLabel.setText("Attempts remaining: " + hangman.getAttempts());
        incorrectGuessesLabel.setText("Incorrect guesses: ");
        guessTextField.setText("");
        guessTextField.requestFocus();
    }

    // TIMER FUNCTIONS
    private void startTimer() {
        timerThread = new Thread(timer);
        timerThread.start();
        ;
    }

    public TimeAttack getTimer() {
        return timer;
    }
    public void updateTimerLabel(int timeRemaining) {
        SwingUtilities.invokeLater(() -> timerLabel.setText("Time remaining: " + timeRemaining + "s"));
    }

    // END GAME MESSAGE FUNCTIONS
    public void closeWindow() {
        setVisible(false);
        dispose();
    }

    public void timeoutEndConditon() {
        String theWord = hangman.getCurrentWord();
        closeWindow(); // Close the window when the timer reaches zero
        endGameMessage("You ran out of time! The word you were looking for was: " + theWord);
    }

    private void endGameMessage(String quote) {
        JOptionPane.showMessageDialog(this, quote, "Game Over :( ",
                JOptionPane.ERROR_MESSAGE);
        timer.end();
    }
}
