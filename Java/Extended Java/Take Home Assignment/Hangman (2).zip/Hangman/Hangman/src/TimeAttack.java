public class TimeAttack implements Runnable {
    private HangmanGUI timeAttackGui;
    private volatile boolean isRunning;
    private int timer;

    public TimeAttack(HangmanGUI timeAttackGui, int startingCount) {
        // RUN PROGRAMME FROM MAIN
        System.out.println("Initializing TimeAttack with starting count: " + startingCount);
        this.timeAttackGui = timeAttackGui;
        this.timer = startingCount;
        this.isRunning = true;
    }

    public int getTimerCount() {
        return timer;
    }

    public void end() {
        // Stop the timer
        isRunning = false;
        System.out.println("Timer stopped.");
    }

    @Override
    public void run() {
        try {
            System.out.println("Timer started with starting count: " + timer);
            while (timer > 0 && isRunning) {
                Thread.sleep(1000); // Sleep for 1 second
                timer--; // Decrease the timer by one second
                System.out.println("Timer: " + timer); // Log the current timer value

                // Update the timer label in the GUI
                timeAttackGui.updateTimerLabel(timer);

                // Check if the timer has reached zero
                if (timer == 0) {
                    System.out.println("Timer reached zero. Triggering timeout end condition.");
                    timeAttackGui.timeoutEndConditon();
                }
            }
        } catch (InterruptedException e) {
            System.err.println("Timer interrupted: " + e.getMessage());
        }
    }

}
