import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

//RULES:
//The game is simple, how many words can you guess before the timer hits zero?
//The game is quite lenient, if you miss a word, you will have the timer reset back to 60 (so the window wont close) but you will lose your count.
//Keep guessing words until you run out of steam or the timer reachers zero.





public class Main {
    private static ArrayList<String> targetWords = new ArrayList<>();
    // RUN FROM THIS FILE
    public static void main(String[] args) throws FileNotFoundException {
        Main main = new Main();
        try {
            Scanner in = new Scanner(new File("Hangman/wordlist.txt"));
            while (in.hasNext()) {
                targetWords.add(in.next());
            }
            in.close();

            if (targetWords.isEmpty()) {
                System.err.println("No words available to play the game.");
                return; // Stop the game
            }
            HangmanGUI timeAttack = main.createTimeAttackGame();
            TimeAttack timer = timeAttack.getTimer();

        } catch (FileNotFoundException e) {
            System.err.println("Wordlist not found");
        }
    }

    public static String getWord() {
        if (targetWords.isEmpty()) {
            throw new IllegalArgumentException("No words available to play the game.");
        }

        Random r = new Random();
        String word = targetWords.get(r.nextInt(targetWords.size()));
        System.out.println("The target word is: " + word);
        return word;
    }

    public HangmanGUI createTimeAttackGame() {
        // Create a new HangmanGUI instance with 5 attempts
        HangmanGUI hangmanGUI = new HangmanGUI(5);
        return hangmanGUI;
    }

}