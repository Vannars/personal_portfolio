import java.util.Arrays;

public class MyMiniList<T> implements MiniList<T> {

    private int size;
    private T[] objectStore;

    public MyMiniList() {
        objectStore = (T[]) new Object[10];
        size = 0;
    }

    @Override
    public void add(T element) {
        if (size == objectStore.length) {
            T[] temp = objectStore;
            objectStore = Arrays.copyOf(temp, 2* size);
        }
            objectStore[size] = element;
            size++;
        }


    @Override
    public T get(int index) {
        if (index < size) {
            T returnElementByIndex = objectStore[index];
            return returnElementByIndex;
        } else {
            return null;
        }
    }

    @Override
    public int getIndex(T element) {
        for (int i = 0; i < size; i++) {
            if (element.equals(objectStore[i])) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void set(int index, T element) {
        objectStore[index] = element;
    }

    @Override
    public int size() {
        if (size > 0) {
            return size;
        }
        return 0;
    }

    @Override
    public T remove(int index) {
        if (index >= 0 && index < size) {
            T removedElement = objectStore[index];
            set(index, null);
            for (int i = index; i < size-1; i++) {
                T shifted = objectStore[i+1];
                set(i, shifted);
            }
            set(size-1, null);
            size--;
            return removedElement;
        }
        return null;
    }

    @Override
    public boolean remove(T element) {
        for(int i = 0; i < size; i++){
            T checkElement = objectStore[i];
            if(checkElement.equals(element)){
                remove(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public void clear() {
        for(int i = size - 1; i >= 0; i--){
            objectStore[i] = null;
            size --; 
        }
    }
}
