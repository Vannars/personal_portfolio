import java.util.Random;

public class PiEstimator {
    // number of iterations the algorithm, a larger number here should result in a
    // more accurate estimate
    //THIS METHOD TAKES AROUND 2 MINUTS TO COMPLETE - please be patient, thank you!
    public static int numberOfDarts = 250_000_000; //Each thread does 250 million each totalling 1 billion

    public static void main(String[] args) {
        TotalWithin totalWithin = new TotalWithin();
        ThrowDarts throwDarts = new ThrowDarts(totalWithin);

        Thread T1 = new Thread(throwDarts);
        Thread T2 = new Thread(throwDarts);
        Thread T3 = new Thread(throwDarts);
        Thread T4 = new Thread(throwDarts);

        T1.start();
        T2.start();
        T3.start();
        T4.start();

        try {
            while (T1.isAlive() || T2.isAlive() || T3.isAlive() || T4.isAlive()) {
                Thread.sleep(3000); // Sleep for 3 seconds
                System.out.println("Current count: " + totalWithin.withinBoard);
            }
            // Wait until threads finish
            T1.join();
            T2.join();
            T3.join();
            T4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // estimate pi by getting proportion of darts in the quarter circle and
        // multiplying by 4.
        int dartsOnBoard = TotalWithin.withinBoard;
        double estimate = (double) dartsOnBoard / numberOfDarts;
        System.out.println("Estimate of PI: " + estimate);

    }

    public static class TotalWithin { // setup a tracking counter
        static int withinBoard = 0; // static reference can be made

        public synchronized void incrementWithinBoard() {
            withinBoard++;
        }
    }

    public static class ThrowDarts extends Thread {
        private TotalWithin totalWithin; // ThrowDarts uses a version TotalWithin

        public ThrowDarts(TotalWithin totalWithin) { // this version is an argument for the public Throw Darts
            this.totalWithin = totalWithin;
        }

        @Override
        public void run() { // use the calculations from the template algorithm
            // how many darts lie within the quarter circle region
            Random r = new Random();
            for (int i = 0; i < numberOfDarts; i++) {
                // get x and y coordinates for the darts
                double x = r.nextDouble();
                double y = r.nextDouble();
                // calculate the distance from the origin (0, 0) darts with a distance less than
                // 1 are within the
                // quarter circle so add these to within
                double dist = Math.sqrt((x * x) + (y * y));
                if (dist < 1)
                    totalWithin.incrementWithinBoard();
            }
        }

    }
}

