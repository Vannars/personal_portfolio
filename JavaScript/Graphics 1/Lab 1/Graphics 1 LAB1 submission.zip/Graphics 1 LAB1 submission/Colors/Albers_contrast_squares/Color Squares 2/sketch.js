///
/// Albers contrast squares
/// by Evan Raskob <e.raskob@gold.ac.uk>
//
/// - Demonstrating using HSB colour mode in p5js.
/// - Learning about saturation, lightness and hue using
///     background contrast.


// Colours for right square, left square, and 
// centre square that sits in both.
// NOTE: these are of object type p5.Color

let leftColor, rightColor, leftcentreColor, rightcentreColor;


//NOAH TAMBALA's Commentary - Through my exploration of colors changing the colors of the center and border colors, I have made a vibrant yellow and vibrant blue color for the boxes. Their relationship is a distance of 180 degrees in terms of angles . According to the book "Understanding Colors" these two colors are complimentary colors because they sit across from each other on the color wheel and so are opposite to each other in terms of hue. Maintaining this same relationship of difference between the colors (of 180 degrees) and adjusting the values will continue to make similar complimentary opposite colors and so it appears that the relationship of 180 degrees is very important for finding opposite colors that are complimentary when using the HSB color mode and measuring color on the scale of 0-360 degrees. 

function setup() {
    createCanvas(400, 400);



    colorMode(HSB);

    let leftHueAngle = 360 - 120; // set this to something fun. 0 is red.

    let hueAngleOffset = 360 - 300;

    leftColor = color(leftHueAngle, 100, 100);
    rightColor = color(hueAngleOffset, 100, 100);

   leftcentreColor =  color(rightColor, 255, 255); // sets the right background color for the left center box
  rightcenterColor = color(leftColor, 255, 255); // sets the left background color for the right center box


}

function draw() {
  background(0);
  
  noStroke();
  rectMode(CORNER);
  fill(leftColor);
  rect(0,0,width/2,height); //left background
  fill(rightColor);
  rect(width/2,0,width/2,height);  //right background
  
  // Draw a smaller rectangle (of a single colour) in the middle 
  // of both squares and experiment with centreColour (above) 
  // until you find a colour that looks different in both but is
  // actually the same colour. What did you change? Share the value.
    
  fill(leftcentreColor); //filles the left center box
  rect(width/8, height/8, width/4, height/2); // draws a box on the left hand side
  fill(rightcenterColor);// fills the right center box
  rect(width/2+ width/8, height/8, width/4, height/2); //draws a box on the right hand side  
}