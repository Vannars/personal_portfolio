/**
 * Cells workshop starter for IS51030B Graphics
 * Create a 3D sphere-shaped container of virtual "cells"
 * 
 * by Evan Raskob, 2021 <e.raskob@gold.ac.uk>
 */


//These are variables which I am using as placeholders to add images I will use as textures
let yellow
let water
//Preloading in my texture images
function preload() { 
    water = loadImage('assets/space.jpg')
    yellow = loadImage('assets/rubber.jpg')
}


// The variable below creates our cells array which we will be using often
let cells = []; // array of cells objects

/**
 * Initialise the cells array with a number of new Cell objects
 * 
 * @param {Integer} maxCells Number of cells for the new array
 * @returns {Array} array of new Cells objects 
 */

//This function creates an array filled with cells. The two for loops push cells of different traits to an internal array
function createCellsArray(maxCells) {
    // EXERCISE: finish this function. It should: 
    // Create an empty new array, fill it with maxCells number of cells, return the array

    // steps:
    let cellsBox = []; // an array to be returned after being populated by cells
    // this for loop iterates the first half the array with randomCells
    for (let i = 0; i < Math.floor(maxCells / 2); i++) {
        let randCell = new Cell({
            position: p5.Vector.random3D(),
            diameter: random(40, 50),
            life: random(50, 3000)
        }); //creates a randomized sized cell
        cellsBox.push(randCell); // pushes it to the array

    }
    //this for loop iterates over the second half of the array
    for (let j = Math.floor(maxCells / 2); j < maxCells; j++) {
        let tinyCell = new Cell({
            position: p5.Vector.random3D().mult(2),
            diameter: 10,
            life: random(50, 2000)
        }); // creates a tiny cell
        cellsBox.push(tinyCell); //pushes it to the array
    }
    return cellsBox; // returns the populated array

}

/**
 * Exercise: draw each of the cells to the screen
 * @param {Array} cellsArray Array of Cell objects to draw 
 */

//This functions draws out cells to the screen - a for loop checks our cellsarray, calls update to update each frame and push/pops a translated and textureds spherical cell to the cells array 
function drawCells3D(cellsArray) {
    // Loop through the cells array, for each cell:
    for (i = 0; i < cellsArray.length; i++) {
        let cell = cellsArray[i]; // create a variable to reference the cellsArray
        cell.update(); // 1. update the cell (call the update function)
        push(); // 2. draw the cell (first push the drawing matrix)
        translate(cell._position.x, cell._position.y, cell._position.z) // 2.1. translate to cell's position
        texture(yellow);
        sphere(cell._diameter); // 2.2 draw a sphere with the cell diameter
        pop(); // 2.3 pop the drawing matrix
    }
    return cellsArray // returns the updated cells array after drawing
}





/**
 * Check collision between two cells (overlapping positions)
 * @param {Cell} cell1 
 * @param {Cell} cell2 
 * @returns {Boolean} true if collided otherwise false
 */

//This function  handles collision checks between cells.It defines the distance between two cells using the getPosition() function in cells.js .
//It also defines the sumOfRadii between these cells by performing calculations  with the getDiamter() function in cells.js
//cell1 and cell2 are arguments to diffentiate between the to cells being compared, but these cells will be officially defined in the collideCells function 
function checkCollision(cell1, cell2) {
    // Exercise: finish this (see the online notes for a full explanation)
    // 1. find the distance between the two cells using p5.Vector's dist() function
    let distance = p5.Vector.dist(cell1.getPosition(), (cell2.getPosition())); // checking the distance between our cell1 and cell2

    // 2. if it is less than the sum of their radii, they are colliding
    let sumOfRadii = cell1.getDiameter() / 2 + cell2.getDiameter() / 2; // this is the sum of the radius between two cells
    if (distance > sumOfRadii) { // if the distance between two cells is greater than the sum of their radii the are not colliding
        return false;
    }

    // 3. return whether they are colliding, or not 
    return true; //in all other cases they are colliding
}


/**
 * Collide two cells together
 * @param {Array} cellsArray Array of Cell objects to draw 
 */
// Iterates over the cells arraay and calls check collision between different cells and performs a calculation of force to simulated a bouncing effect of opposing forces
function collideCells(cellsArray) {
    // 1. go through the array
    for (let cell1 of cellsArray) {
        for (let cell2 of cellsArray) {
            if (cell1 !== cell2) // don't collide with itself or *all* cells will bounce!
            {
                if (checkCollision(cell1, cell2)) {
                    // get direction of collision, from cell2 to cell1
                    let collisionDirection = p5.Vector.sub(cell1.getPosition(), cell2.getPosition()).normalize();
                    cell2.applyForce(collisionDirection.mult(5)); // we calculated the direction as from 2-1 so this is backwards
                    cell1.applyForce(collisionDirection.mult(-3));
                }
            }
        }
    }
}

/**
 * Constrain cells to sphere world boundaries.
 * @param {Array} cellsArray Array of Cell objects to draw 
 */
function constrainCells(cellsArray, worldCenterPos, worldDiameter) {
    // 1. go through the array
    for (let cell of cellsArray) {
        cell.constrainToSphere(worldCenterPos, worldDiameter);
    }
}

//this function returns all cells with a value of life grater than zero 
function isAlive(cell) {
    return cell._life > 0; //returns all cell values greater than 0 
}

//this function checks the cellsArray by filtering and returning only the "alive" cells with values above zero by calling th isAlive function
function getAlive(cellsArray) {

    return cellsArray.filter(cell => isAlive(cell)); //returns a cellsArray with the "dead" cells filtered out
}

/**
 * Setup functions
 */

function setup() {
    colorMode(RGB);
    createCanvas(800, 600, WEBGL);


    // Exercise 1: test out the constructor function.
    // What should you see printed in teh console if successful?

    //  let testCell = new Cell({
    //    position: createVector(1,2,3),
    //    velocity: createVector(-1,-2,-3),
    //    life: 600,
    //    diameter: 35
    //  });
    //  
    //  console.log("Testing cell:");
    //  console.log(testCell);

    // This is for part 2: creating a list of cells
    cells = createCellsArray(20); // sets our array length
    console.log(cells) // for testing
}


///----------------------------------------------------------------------------
/// p5js draw function 
///--------------------------------------------------s-------------------------
function draw() {

    orbitControl(); // camera control using mouse

    //lights(); // we're using custom lights here
    directionalLight(180, 180, 180, 0, 0, -width / 2);
    directionalLight(255, 255, 255, 0, 0, width / 2);

    ambientLight(random(50, 25)); //edited lighting
    pointLight(200, 200, 200, 0, 0, 0, 50);
    noStroke();
    background(80); // clear screen
    normalMaterial(0, 210, 40)
    specularMaterial(8) // added speculart material for stylistic purposes
    ambientMaterial(80, 20, 255); // magenta material

    cells = getAlive(cells); // removes alive cells from our array before collisions are detected
    collideCells(cells); // handle collisions
    constrainCells(cells, createVector(0, 0, 0), width); // keep cells in the world
    drawCells3D(cells); // draw the cells

    // draw world boundaries
    ambientMaterial(0); // magenta material for subsequent objects
    texture(water);
    ambientLight(255);
    sphere(width); // this is the border of the world, a little like a "skybox" in video games
}
