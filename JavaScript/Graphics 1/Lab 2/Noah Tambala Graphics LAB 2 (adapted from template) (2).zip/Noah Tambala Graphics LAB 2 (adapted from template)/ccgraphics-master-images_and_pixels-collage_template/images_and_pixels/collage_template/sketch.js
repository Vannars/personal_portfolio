/**
 * ----------------------------------------------------------------------
 * NOTE: If you use this file, please change the comments to reflect your
 *       changes and additions!
 * ---------------------------------------------------------------------
 * Example starter template for making an image collage which has been
 * modified by <NOAH TAMBALA and ntamb002@gold.ac.uk>
 * -----------------------------------------
 * 
 READ THIS IF THE SKETCH IS NOT RUNNING---- Running the html file does not display the sketch file properly and I am unsure why as I had this problem with the template folder before transforming the code for my piece. Neither does running ths sketch file directly. Please open the folder which contains the sketch file and other asset folders as a brackets project and then run in the live preview. If you use VS Code please use the the live preview extension for that IDE. 
 
 
 For this task I have attempted to create a surrealist science fiction scene with elements "superimposed" over a naturalistic setting.
 * Thematically I wanted to draw upop surrealism, science fiction and horror.
 * For research on how to incorperate external imagery into naturalistic setting I explored Deviant Art.
 * 
   VictorSauron on Deviant art creates surrealist pieces with video game characters are imposed over real life backdrops.
   The sprites he uses are png files and so I found this the perfect inspiration of how incorperate imagery my piece. 
   
   I also took inspiration from the 2002 film 'Signs' staring Mel Gibson 
   https://m.media-amazon.com/images/M/MV5BZWI0ZDUwNmUtODMzYS00Yzk0LTk2YjQtNTJjZDA4ODY1OGYwXkEyXkFqcGdeQXVyMTE2NzA0Ng@@._V1_.jpg
   The image I linked above is a still from Signs depicting an alien on a found footage tape. This style of alien and found footage creates the exact aesthetic I wanted for my piece.  

   Brining these two ideas together I needed a backdrop that I wanted to edit. For the backdrop image I have taken a photo in my local area on my mobile phone.
   After this I needed images that I could present as being "projected" into the world and so I sourced royalty free png images.

 * Below are the Images I have sourced are from royalty image websites. 
 * https://www.pngegg.com/en/png-wgdai/download - I chose an UFO to play directly into the science fiction theme which is also perfect for manipulating wihin the scene.
 * https://www.pngwing.com/en/free-png-dcviq/download - This image of the alien is creepy but a little dull. I used it as a base to be edited with filters which would create a creepy alien to play into the horror theme.
 To note these images do not appear to have authors, only download links. Therefore I can only cite these site links as sources. 
 */
let alien;
let ufo;
let Paul;

/// --- PRELOAD ------------------------
/// This is useful to load an image  or do a task that is important to run
/// *before* the sketch is loaded. preload() runs once *before* setup

function preload() {
    // load images from the assets folder
    alien = loadImage('images/alien.png');
    Paul = loadImage('images/Paul.jpg');
    ufo = loadImage('images/ufo.png')

    pixelDensity(1); // if you are on a very large screen, this can
    // help your images scale to the proper size when drawn
}

///
/// Setup -------------------------
///
function setup() {

    // LOW FRAMERATE FOR MY GLITCH EFFECT
    frameRate(10)

    console.info('Image dimensions');
    console.info('----------------');
    console.info('alien:' + alien.width + '/' + alien.height);
    console.info('Paul:' + Paul.width + '/' + Paul.height);
    console.info('ufo:' + ufo.width + '/' + ufo.height);

    createCanvas(Paul.width - 70, Paul.height - 280); // create a canvas EXACTLY the size of our image

    // Make the ufo blur and appear more natrual within the scene
    ufo.filter(POSTERIZE, 3)
    ufo.filter(BLUR, 2)
    //These filter create shading on the alien and blur to make the alien appear more natural within the scene
    alien.filter(BLUR, 1.8)
    alien.filter(POSTERIZE, 5)
    alien.filter(DILATE, 5)
}

/**
 *
 * 
 * @param {Number} x center coordinate on canvas to start drawing 
 * @param {Number} y center coordinate on canvas to start drawing 
 * @param {Number} w (optional) width of image to draw on canvas 
 * @param {Number} h (optional) height of image to draw on canvas
 */
// GLOBAL UFO VARIABLES
let ufoX = 50
let ufoY = -1;
let yDirection = 1;
let xDirection = 2.1;
// The drawUfo fucntion is used to draw the ufo image onto the canvass which moves along the yaxis and 
// appears to occilate in size and shape. The pixel array as also been used to make the ufo have a "fuzzy" found footage appeal to it.
function drawUfo(x, y, w, h, minX, maxX) {
    // loadPixels to edit  ufo in the pixels array
    ufo.loadPixels();
    // setting parameters for direction of ufo movement

    //ufoY moves based on yDirection;
    ufoY += yDirection;
    // ufoX moves based on xDirection;
    ufoX += xDirection;
    // conditions of the ufo boundes in yaxis
    if (ufoY < -75 || ufoY > 75) {
        yDirection *= -1;
    }
    // conditions of the ufo bounds in xais
    if (ufoX < minX) {
        ufoX = minX;
        xDirection *= -1;
    } else if (ufoX > maxX) {
        ufoX = maxX;
        xDirection *= -1;
    }
    //** NOT USED ** but if the ufo was allowed to move across the screen this would loop it around
    if (ufoX > width + ufo.width) {
        ufoX = -ufo.width;
    }
    // use pixel array to alter the colors of the ufo to make them fuzzy
    for (let i = 0; i < ufo.pixels.length; i += 20) {
        ufo.pixels[i] = random(0, 255); // Red
        ufo.pixels[i + 1] = random(0, 255); // Green
        ufo.pixels[i + 2] = random(0, 255); // Blue
    }
    // define sections to alter the "state" of the ufo (a.k.a make it appear to morph)
    var sectionWidth = int(random(ufo.width / 2, ufo.width));
    var sectionHeight = int(random(ufo.height / 2, ufo.height));
    // Draw the ufo image with modified x-position
    image(ufo, ufoX + x, y + 100 + ufoY - h / 2, sectionWidth * 0.5, sectionHeight);
    // update to see the results
    ufo.updatePixels();
}
// The drawUfoShadow function works in exactly the same way as the drawufo function except it is drawn with a threshold filter to
// draw the shadow of the ufo before being tranlated into the draw fucntion
function drawUfoShadow(x, y, w, h, minX, maxX) {
    // loadPixels to edit  ufo in the pixels array
    ufo.loadPixels();
    // setting parameters for direction of ufo movement
    //ufoY moves based on yDirection;
    ufoY += yDirection;
    // ufoX moves based on xDirection;
    ufoX += xDirection;
    // conditions of the ufo boundes in yaxis
    if (ufoY < -75 || ufoY > 75) {
        yDirection *= -1;
    }
    // conditions of the ufo bounds in xais
    if (ufoX < minX) {
        ufoX = minX;
        xDirection *= -1;
    } else if (ufoX > maxX) {
        ufoX = maxX;
        xDirection *= -1;
    }
    //** NOT USED ** but if the ufo was allowed to move across the screen this would loop it around
    if (ufoX > width + ufo.width) {
        ufoX = -ufo.width;
    }
    // use pixel array to alter the colors of the ufo to make them fuzzy
    for (let i = 0; i < ufo.pixels.length; i += 20) {
        ufo.pixels[i] = random(0, 255); // Red
        ufo.pixels[i + 1] = random(0, 255); // Green
        ufo.pixels[i + 2] = random(0, 255); // Blue
    }
    // define sections to alter the "state" of the ufo (a.k.a make it appear to morph)
    var sectionWidth = int(random(ufo.width / 2, ufo.width));
    var sectionHeight = int(random(ufo.height / 2, ufo.height));

    // Draw the ufo image with modified x-position and THRESHOLD of 1
    ufo.filter(THRESHOLD, 1)
    image(ufo, ufoX + x, y + 100 + ufoY - h / 2, sectionWidth * 1.2, sectionHeight*1.15);
    // update to see the results
    ufo.updatePixels();
}

//the drawAlien function draws the alien to the canvas and also uses the pixel array  to overlay a 
//pattern over the png to create an "animated" look to the alien
function drawAlien(x, y, w, h) {
    // loadpixels to edit
    alien.loadPixels();
    //iterate of the pixels of the alien
    for (let i = 0; i < alien.pixels.length; i += 40) {
        // creating a strange "imposed" effect on the alien
        alien.pixels[i] = random(255); // Red
        alien.pixels[i + 1] = random(255); // Green
        alien.pixels[i + 2] = random(255); // Blue

    }
    // draw the alien
    image(alien, x, y, w, h);
    //update pixels to see the results
    alien.updatePixels();
}

//works in the same way as the drawAlien fucntion except with POSTERISE and THRESHOLD used to reset the filters to make the shadow
function drawAlienShadow(x, y, w, h) {
    // loadpixels to edit
    alien.loadPixels();
    // draw the alien
    translate(0, alien.height);
    scale(1, -1)
    alien.filter(POSTERIZE)
    alien.filter(THRESHOLD)
    image(alien, x, y, w, h);
    //update ixels to see the results
    alien.updatePixels();
}



/**
 * Draw a mask image onto the screen using SCREEN blend mode.
 * This means the black parts of this image will white out the
 * pixels below it, and the white parts of this image will let the 
 * pixels below show through unaltered.
 * 
 * @param {p5.Image} img Mask image
 * @param {Number} x 
 * @param {Number} y 
 * @param {Number} w 
 * @param {Number} h 
 */
function drawMask(img, x, y, w, h) {
    // or try screen
    blendMode(SCREEN);
    imageMode(CENTER); // draw using center coordinate
    image(img, x, y, w, h);
}



///-----------------------------
///--- DRAW --------------------
///-----------------------------

function draw() {

    tint(255, 255); // reset tint for normal tint for Paul pic
    image(Paul, 0, 0);

    tint(215, 163, 180, 225) // tint to make Alien pink
    drawAlien(width / 7 + 205, width / 3 + 109, alien.width / 2.2, alien.height / 1.4);

    tint(0, 0, 90, 160) // tinto for a semi transparent shadow for the alien
    drawAlienShadow((width / 6 + 183), -(width / 3 + 170), alien.width / 2.2, alien.height / 1.4 - 3);

    translate(0, -alien.height) // translates the alien in the yaxis
    scale(1, -1) // by minus 1
    tint(105, 145, 205)
    drawUfo(170, -360, ufo.width, ufo.height * random(0, 0, 0.01), random(2, 2.1), random(2, 6));

    translate(0, -ufo.height) // translate the ufo shadow 
    scale(1, -1) // by minus 1
    tint(0, 0, 0, alien.height * 0.8) // semi transparent shadow for the ufo
    drawUfoShadow(170, -355, ufo.width, ufo.height * random(0, 0, 0.01), random(2, 2.1), random(2, 6))
} // end draw()
